import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

public class ContactServiceTest {

    private Contact buildContact(String id) {
        return new Contact(id, "Tay", "Brown", "1234567890", "123 Main St");
    }

    @Test
    void testAddContactStoresContact() {
        ContactService service = new ContactService();
        service.addContact(buildContact("1"));
        assertNotNull(service.getContact("1"));
        assertEquals("Tay", service.getContact("1").getFirstName());
    }

    @Test
    void testAddDuplicateIdThrows() {
        ContactService service = new ContactService();
        service.addContact(buildContact("1"));
        assertThrows(IllegalArgumentException.class, () -> service.addContact(buildContact("1")));
    }

    @Test
    void testDeleteContactRemovesContact() {
        ContactService service = new ContactService();
        service.addContact(buildContact("1"));
        service.deleteContact("1");
        assertNull(service.getContact("1"));
    }

    @Test
    void testDeleteMissingContactThrows() {
        ContactService service = new ContactService();
        assertThrows(IllegalArgumentException.class, () -> service.deleteContact("missing"));
    }

    @Test
    void testUpdateFieldsByContactId() {
        ContactService service = new ContactService();
        service.addContact(buildContact("1"));

        service.updateFirstName("1", "NewFirst");
        service.updateLastName("1", "NewLast");
        service.updatePhone("1", "0987654321");
        service.updateAddress("1", "456 Market St");

        Contact updated = service.getContact("1");
        assertEquals("1", updated.getContactId(), "contactId should not be updatable");
        assertEquals("NewFirst", updated.getFirstName());
        assertEquals("NewLast", updated.getLastName());
        assertEquals("0987654321", updated.getPhone());
        assertEquals("456 Market St", updated.getAddress());
    }

    @Test
    void testUpdateMissingIdThrows() {
        ContactService service = new ContactService();
        assertThrows(IllegalArgumentException.class, () -> service.updateFirstName("missing", "X"));
        assertThrows(IllegalArgumentException.class, () -> service.updateLastName("missing", "X"));
        assertThrows(IllegalArgumentException.class, () -> service.updatePhone("missing", "1234567890"));
        assertThrows(IllegalArgumentException.class, () -> service.updateAddress("missing", "123 Main St"));
    }

    @Test
    void testUpdateRejectsInvalidValues() {
        ContactService service = new ContactService();
        service.addContact(buildContact("1"));

        assertThrows(IllegalArgumentException.class, () -> service.updateFirstName("1", null));
        assertThrows(IllegalArgumentException.class, () -> service.updateLastName("1", null));
        assertThrows(IllegalArgumentException.class, () -> service.updatePhone("1", "123"));
        assertThrows(IllegalArgumentException.class, () -> service.updateAddress("1", "1234567890123456789012345678901"));
    }
}
