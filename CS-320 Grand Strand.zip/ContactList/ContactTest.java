import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

public class ContactTest {

    @Test
    void testCreateValidContact() {
        Contact c = new Contact("1", "Tay", "Brown", "1234567890", "123 Main St");
        assertEquals("1", c.getContactId());
        assertEquals("Tay", c.getFirstName());
        assertEquals("Brown", c.getLastName());
        assertEquals("1234567890", c.getPhone());
        assertEquals("123 Main St", c.getAddress());
    }

    @Test
    void testContactIdNullOrTooLongThrows() {
        assertThrows(IllegalArgumentException.class,
                () -> new Contact(null, "Tay", "Brown", "1234567890", "123 Main St"));
        assertThrows(IllegalArgumentException.class,
                () -> new Contact("12345678901", "Tay", "Brown", "1234567890", "123 Main St"));
    }

    @Test
    void testFirstNameNullOrTooLongThrows() {
        assertThrows(IllegalArgumentException.class,
                () -> new Contact("1", null, "Brown", "1234567890", "123 Main St"));
        assertThrows(IllegalArgumentException.class,
                () -> new Contact("1", "12345678901", "Brown", "1234567890", "123 Main St"));
    }

    @Test
    void testLastNameNullOrTooLongThrows() {
        assertThrows(IllegalArgumentException.class,
                () -> new Contact("1", "Tay", null, "1234567890", "123 Main St"));
        assertThrows(IllegalArgumentException.class,
                () -> new Contact("1", "Tay", "12345678901", "1234567890", "123 Main St"));
    }

    @Test
    void testPhoneNullOrInvalidFormatThrows() {
        assertThrows(IllegalArgumentException.class,
                () -> new Contact("1", "Tay", "Brown", null, "123 Main St"));
        assertThrows(IllegalArgumentException.class,
                () -> new Contact("1", "Tay", "Brown", "123", "123 Main St"));
        assertThrows(IllegalArgumentException.class,
                () -> new Contact("1", "Tay", "Brown", "123456789a", "123 Main St"));
    }

    @Test
    void testAddressNullOrTooLongThrows() {
        assertThrows(IllegalArgumentException.class,
                () -> new Contact("1", "Tay", "Brown", "1234567890", null));
        assertThrows(IllegalArgumentException.class,
                () -> new Contact("1", "Tay", "Brown", "1234567890",
                        "1234567890123456789012345678901")); // 31 chars
    }

    @Test
    void testUpdatableFieldsUpdateAndIdStaysSame() {
        Contact c = new Contact("1", "Tay", "Brown", "1234567890", "123 Main St");
        c.setFirstName("T");
        c.setLastName("B");
        c.setPhone("0987654321");
        c.setAddress("456 Market St");

        assertEquals("1", c.getContactId(), "contactId should not change");
        assertEquals("T", c.getFirstName());
        assertEquals("B", c.getLastName());
        assertEquals("0987654321", c.getPhone());
        assertEquals("456 Market St", c.getAddress());
    }

    @Test
    void testSettersRejectInvalidValues() {
        Contact c = new Contact("1", "Tay", "Brown", "1234567890", "123 Main St");

        assertThrows(IllegalArgumentException.class, () -> c.setFirstName(null));
        assertThrows(IllegalArgumentException.class, () -> c.setFirstName("12345678901"));

        assertThrows(IllegalArgumentException.class, () -> c.setLastName(null));
        assertThrows(IllegalArgumentException.class, () -> c.setLastName("12345678901"));

        assertThrows(IllegalArgumentException.class, () -> c.setPhone(null));
        assertThrows(IllegalArgumentException.class, () -> c.setPhone("123"));
        assertThrows(IllegalArgumentException.class, () -> c.setPhone("123456789a"));

        assertThrows(IllegalArgumentException.class, () -> c.setAddress(null));
        assertThrows(IllegalArgumentException.class, () -> c.setAddress("1234567890123456789012345678901"));
    }
}
