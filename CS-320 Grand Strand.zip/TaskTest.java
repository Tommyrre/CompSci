
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

public class TaskTest {

    @Test
    void testValidTaskCreation() {
        Task task = new Task("123", "Name", "Description");
        assertEquals("123", task.getTaskId());
        assertEquals("Name", task.getName());
        assertEquals("Description", task.getDescription());
    }

    @Test
    void testTaskIdNull() {
        assertThrows(IllegalArgumentException.class,
                () -> new Task(null, "Name", "Description"));
    }

    @Test
    void testTaskIdTooLong() {
        assertThrows(IllegalArgumentException.class,
                () -> new Task("12345678901", "Name", "Description"));
    }

    @Test
    void testNameNull() {
        assertThrows(IllegalArgumentException.class,
                () -> new Task("123", null, "Description"));
    }

    @Test
    void testNameTooLong() {
        assertThrows(IllegalArgumentException.class,
                () -> new Task("123", "123456789012345678901", "Description"));
    }

    @Test
    void testDescriptionNull() {
        assertThrows(IllegalArgumentException.class,
                () -> new Task("123", "Name", null));
    }

    @Test
    void testDescriptionTooLong() {
        assertThrows(IllegalArgumentException.class,
                () -> new Task("123", "Name",
                        "123456789012345678901234567890123456789012345678901"));
    }

    @Test
    void testUpdateName() {
        Task task = new Task("123", "Old", "Desc");
        task.setName("New");
        assertEquals("New", task.getName());
    }

    @Test
    void testUpdateDescription() {
        Task task = new Task("123", "Name", "Old");
        task.setDescription("New");
        assertEquals("New", task.getDescription());
    }
}
