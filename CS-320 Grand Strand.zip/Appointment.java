import java.util.Date;

public class Appointment {
    private final String appointmentId;
    private Date appointmentDate;
    private String description;

    public Appointment(String appointmentId, Date appointmentDate, String description) {
        if (appointmentId == null || appointmentId.trim().isEmpty())
            throw new IllegalArgumentException("Appointment ID cannot be null or empty.");
        if (appointmentId.length() > 10)
            throw new IllegalArgumentException("Appointment ID cannot be longer than 10 characters.");
        if (appointmentDate == null)
            throw new IllegalArgumentException("Appointment date cannot be null.");
        if (appointmentDate.before(new Date()))
            throw new IllegalArgumentException("Appointment date cannot be in the past.");
        if (description == null || description.trim().isEmpty())
            throw new IllegalArgumentException("Description cannot be null or empty.");
        if (description.length() > 50)
            throw new IllegalArgumentException("Description cannot be longer than 50 characters.");

        this.appointmentId = appointmentId;
        this.appointmentDate = new Date(appointmentDate.getTime());
        this.description = description;
    }

    public String getAppointmentId() { return appointmentId; }

    public Date getAppointmentDate() { return new Date(appointmentDate.getTime()); }

    public void setAppointmentDate(Date appointmentDate) {
        if (appointmentDate == null || appointmentDate.before(new Date()))
            throw new IllegalArgumentException("Invalid appointment date.");
        this.appointmentDate = new Date(appointmentDate.getTime());
    }

    public String getDescription() { return description; }

    public void setDescription(String description) {
        if (description == null || description.length() > 50)
            throw new IllegalArgumentException("Invalid description.");
        this.description = description;
    }
}
