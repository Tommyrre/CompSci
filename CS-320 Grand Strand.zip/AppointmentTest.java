import static org.junit.jupiter.api.Assertions.*;

import java.util.Date;

import org.junit.jupiter.api.Test;

public class AppointmentTest {

    private Date futureDate() {
        return new Date(System.currentTimeMillis() + 120000); // +2 minutes
    }

    private Date pastDate() {
        return new Date(System.currentTimeMillis() - 120000); // -2 minutes
    }

    @Test
    void testAppointmentCreationValid() {
        Appointment appt = new Appointment("A123", futureDate(), "Checkup");
        assertEquals("A123", appt.getAppointmentId());
        assertEquals("Checkup", appt.getDescription());
        assertNotNull(appt.getAppointmentDate());
    }

    @Test
    void testAppointmentIdNullEmptyOrTooLongThrows() {
        assertThrows(IllegalArgumentException.class,
                () -> new Appointment(null, futureDate(), "Checkup"));
        assertThrows(IllegalArgumentException.class,
                () -> new Appointment("   ", futureDate(), "Checkup"));
        assertThrows(IllegalArgumentException.class,
                () -> new Appointment("12345678901", futureDate(), "Checkup"));
    }

    @Test
    void testAppointmentDateNullOrPastThrows() {
        assertThrows(IllegalArgumentException.class,
                () -> new Appointment("A1", null, "Checkup"));
        assertThrows(IllegalArgumentException.class,
                () -> new Appointment("A1", pastDate(), "Checkup"));
    }

    @Test
    void testDescriptionNullEmptyOrTooLongThrows() {
        assertThrows(IllegalArgumentException.class,
                () -> new Appointment("A1", futureDate(), null));
        assertThrows(IllegalArgumentException.class,
                () -> new Appointment("A1", futureDate(), "   "));
        assertThrows(IllegalArgumentException.class,
                () -> new Appointment("A1", futureDate(),
                        "123456789012345678901234567890123456789012345678901")); // 51 chars
    }

    @Test
    void testSetAppointmentDateValidAndInvalid() {
        Appointment appt = new Appointment("A1", futureDate(), "Dentist");
        Date newFuture = new Date(System.currentTimeMillis() + 300000);
        appt.setAppointmentDate(newFuture);
        assertEquals(newFuture.getTime(), appt.getAppointmentDate().getTime());

        assertThrows(IllegalArgumentException.class, () -> appt.setAppointmentDate(null));
        assertThrows(IllegalArgumentException.class, () -> appt.setAppointmentDate(pastDate()));
    }

    @Test
    void testSetDescriptionValidAndInvalid() {
        Appointment appt = new Appointment("A1", futureDate(), "Dentist");
        appt.setDescription("Follow-up");
        assertEquals("Follow-up", appt.getDescription());

        assertThrows(IllegalArgumentException.class, () -> appt.setDescription(null));
        assertThrows(IllegalArgumentException.class,
                () -> appt.setDescription("123456789012345678901234567890123456789012345678901"));
    }

    @Test
    void testAppointmentIdNotUpdatable() {
        Appointment appt = new Appointment("A1", futureDate(), "Dentist");
        appt.setDescription("Updated");
        assertEquals("A1", appt.getAppointmentId());
    }
}
