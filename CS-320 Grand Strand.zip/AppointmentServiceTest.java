import static org.junit.jupiter.api.Assertions.*;

import java.util.Date;

import org.junit.jupiter.api.Test;

public class AppointmentServiceTest {

    private Appointment buildAppointment(String id) {
        Date future = new Date(System.currentTimeMillis() + 120000);
        return new Appointment(id, future, "Dentist");
    }

    @Test
    void testAddAppointmentAndGet() {
        AppointmentService service = new AppointmentService();
        Appointment appt = buildAppointment("A1");
        service.addAppointment(appt);

        assertEquals(1, service.size());
        assertNotNull(service.getAppointment("A1"));
        assertEquals("A1", service.getAppointment("A1").getAppointmentId());
    }

    @Test
    void testAddNullAppointmentThrows() {
        AppointmentService service = new AppointmentService();
        assertThrows(IllegalArgumentException.class, () -> service.addAppointment(null));
    }

    @Test
    void testAddDuplicateAppointmentIdThrows() {
        AppointmentService service = new AppointmentService();
        service.addAppointment(buildAppointment("A1"));
        assertThrows(IllegalArgumentException.class, () -> service.addAppointment(buildAppointment("A1")));
    }

    @Test
    void testDeleteAppointmentRemovesIt() {
        AppointmentService service = new AppointmentService();
        service.addAppointment(buildAppointment("A1"));
        service.deleteAppointment("A1");

        assertEquals(0, service.size());
        assertNull(service.getAppointment("A1"));
    }

    @Test
    void testDeleteMissingAppointmentThrows() {
        AppointmentService service = new AppointmentService();
        assertThrows(IllegalArgumentException.class, () -> service.deleteAppointment("missing"));
    }
}
