
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class TaskServiceTest {

    private TaskService service;

    @BeforeEach
    void setup() {
        service = new TaskService();
    }

    @Test
    void testAddTask() {
        Task task = new Task("1", "Task", "Description");
        service.addTask(task);
        assertNotNull(service.getTask("1"));
    }

    @Test
    void testAddDuplicateTask() {
        service.addTask(new Task("1", "Task", "Description"));
        assertThrows(IllegalArgumentException.class,
                () -> service.addTask(new Task("1", "Task2", "Description2")));
    }

    @Test
    void testDeleteTask() {
        service.addTask(new Task("1", "Task", "Description"));
        service.deleteTask("1");
        assertNull(service.getTask("1"));
    }

    @Test
    void testUpdateTaskName() {
        service.addTask(new Task("1", "Old", "Desc"));
        service.updateTaskName("1", "New");
        assertEquals("New", service.getTask("1").getName());
    }

    @Test
    void testUpdateTaskDescription() {
        service.addTask(new Task("1", "Task", "Old"));
        service.updateTaskDescription("1", "New");
        assertEquals("New", service.getTask("1").getDescription());
    }

    @Test
    void testUpdateNonexistentTask() {
        assertThrows(IllegalArgumentException.class,
                () -> service.updateTaskName("999", "New"));
    }
}
