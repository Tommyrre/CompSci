///////////////////////////////////////////////////////////////////////////////
// shadermanager.cpp
// ============
// manage the loading and setting of shader code
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//	Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
//
//  UPDATED: Adds uniform helper functions used by SceneManager
///////////////////////////////////////////////////////////////////////////////

#include <stdio.h>
#include <string>
#include <vector>
#include <iostream>
#include <fstream>
#include <sstream>
using namespace std;

#include <stdlib.h>
#include <string.h>

#include <GL/glew.h>

#include <glm/gtc/type_ptr.hpp>

#include "ShaderManager.h"

ShaderManager::ShaderManager()
{
	m_programID = 0;
}

ShaderManager::~ShaderManager()
{
	if (m_programID != 0)
	{
		glDeleteProgram(m_programID);
		m_programID = 0;
	}
}

void ShaderManager::use()
{
	if (m_programID != 0)
		glUseProgram(m_programID);
}

GLuint ShaderManager::getProgramID() const
{
	return m_programID;
}

GLint ShaderManager::getUniformLocation(const char* name) const
{
	if (m_programID == 0 || name == nullptr)
		return -1;

	return glGetUniformLocation(m_programID, name);
}

void ShaderManager::setBoolValue(const char* name, bool value) const
{
	GLint loc = getUniformLocation(name);
	if (loc >= 0) glUniform1i(loc, (int)value);
}

void ShaderManager::setIntValue(const char* name, int value) const
{
	GLint loc = getUniformLocation(name);
	if (loc >= 0) glUniform1i(loc, value);
}

void ShaderManager::setFloatValue(const char* name, float value) const
{
	GLint loc = getUniformLocation(name);
	if (loc >= 0) glUniform1f(loc, value);
}

void ShaderManager::setVec3Value(const char* name, const glm::vec3& value) const
{
	GLint loc = getUniformLocation(name);
	if (loc >= 0) glUniform3fv(loc, 1, glm::value_ptr(value));
}

void ShaderManager::setVec4Value(const char* name, const glm::vec4& value) const
{
	GLint loc = getUniformLocation(name);
	if (loc >= 0) glUniform4fv(loc, 1, glm::value_ptr(value));
}

void ShaderManager::setMat4Value(const char* name, const glm::mat4& value) const
{
	GLint loc = getUniformLocation(name);
	if (loc >= 0) glUniformMatrix4fv(loc, 1, GL_FALSE, glm::value_ptr(value));
}

/***********************************************************
 *  LoadShaders()
 *
 *  This method is called to load the shader data from
 *  external GLSL compatible files.
 ***********************************************************/
GLuint ShaderManager::LoadShaders(const char* vertex_file_path, const char* fragment_file_path)
{
	GLuint VertexShaderID = glCreateShader(GL_VERTEX_SHADER);
	GLuint FragmentShaderID = glCreateShader(GL_FRAGMENT_SHADER);

	// Read Vertex Shader
	std::string VertexShaderCode;
	std::ifstream VertexShaderStream(vertex_file_path, std::ios::in);
	if (VertexShaderStream.is_open())
	{
		std::stringstream sstr;
		sstr << VertexShaderStream.rdbuf();
		VertexShaderCode = sstr.str();
		VertexShaderStream.close();
	}
	else
	{
		printf("Impossible to open %s.\n", vertex_file_path);
		getchar();
		return 0;
	}

	// Read Fragment Shader
	std::string FragmentShaderCode;
	std::ifstream FragmentShaderStream(fragment_file_path, std::ios::in);
	if (FragmentShaderStream.is_open())
	{
		std::stringstream sstr;
		sstr << FragmentShaderStream.rdbuf();
		FragmentShaderCode = sstr.str();
		FragmentShaderStream.close();
	}
	else
	{
		printf("Impossible to open %s.\n", fragment_file_path);
		getchar();
		return 0;
	}

	GLint Result = GL_FALSE;
	int InfoLogLength;

	// Compile Vertex Shader
	printf("Compiling shader : %s...", vertex_file_path);
	char const* VertexSourcePointer = VertexShaderCode.c_str();
	glShaderSource(VertexShaderID, 1, &VertexSourcePointer, NULL);
	glCompileShader(VertexShaderID);

	glGetShaderiv(VertexShaderID, GL_COMPILE_STATUS, &Result);
	glGetShaderiv(VertexShaderID, GL_INFO_LOG_LENGTH, &InfoLogLength);
	if (InfoLogLength > 0)
	{
		std::vector<char> VertexShaderErrorMessage(InfoLogLength + 1);
		glGetShaderInfoLog(VertexShaderID, InfoLogLength, NULL, &VertexShaderErrorMessage[0]);
		printf("\n%s\n", &VertexShaderErrorMessage[0]);
	}
	printf("success\n");

	// Compile Fragment Shader
	printf("Compiling shader : %s...", fragment_file_path);
	char const* FragmentSourcePointer = FragmentShaderCode.c_str();
	glShaderSource(FragmentShaderID, 1, &FragmentSourcePointer, NULL);
	glCompileShader(FragmentShaderID);

	glGetShaderiv(FragmentShaderID, GL_COMPILE_STATUS, &Result);
	glGetShaderiv(FragmentShaderID, GL_INFO_LOG_LENGTH, &InfoLogLength);
	if (InfoLogLength > 0)
	{
		std::vector<char> FragmentShaderErrorMessage(InfoLogLength + 1);
		glGetShaderInfoLog(FragmentShaderID, InfoLogLength, NULL, &FragmentShaderErrorMessage[0]);
		printf("\n%s\n", &FragmentShaderErrorMessage[0]);
	}
	printf("success\n");

	// Link Program
	printf("Linking shader program...");
	GLuint ProgramID = glCreateProgram();
	glAttachShader(ProgramID, VertexShaderID);
	glAttachShader(ProgramID, FragmentShaderID);
	glLinkProgram(ProgramID);

	glGetProgramiv(ProgramID, GL_LINK_STATUS, &Result);
	glGetProgramiv(ProgramID, GL_INFO_LOG_LENGTH, &InfoLogLength);
	if (InfoLogLength > 1)
	{
		std::vector<char> ProgramErrorMessage(InfoLogLength + 1);
		glGetProgramInfoLog(ProgramID, InfoLogLength, NULL, &ProgramErrorMessage[0]);
		printf("\n%s\n", &ProgramErrorMessage[0]);
	}
	printf("success\n");

	glDetachShader(ProgramID, VertexShaderID);
	glDetachShader(ProgramID, FragmentShaderID);
	glDeleteShader(VertexShaderID);
	glDeleteShader(FragmentShaderID);

	// store program id for use()/uniforms
	m_programID = ProgramID;

	return ProgramID;
}
