///////////////////////////////////////////////////////////////////////////////
// scenemanager.cpp
// ============
// manage the preparing and rendering of 3D scenes - textures, materials, lighting
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//  Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
//
///////////////////////////////////////////////////////////////////////////////

#include "SceneManager.h"

#ifndef STB_IMAGE_IMPLEMENTATION
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#endif

#include <iostream>
#include <sstream>
#include <glm/gtc/type_ptr.hpp>
#include <glm/gtx/transform.hpp>

namespace
{
	const char* g_ModelName = "model";
	const char* g_ObjectColorName = "objectColor";
	const char* g_ObjectTextureName = "objectTexture";
	const char* g_UseTextureName = "bUseTexture";
	const char* g_UseLightingName = "bUseLighting";
}

/***********************************************************/
SceneManager::SceneManager(ShaderManager* pShaderManager)
{
	m_pShaderManager = pShaderManager;
	m_basicMeshes = new ShapeMeshes();

	m_loadedTextures = 0;
	for (int i = 0; i < 16; i++)
	{
		m_textureIDs[i].tag = "";
		m_textureIDs[i].ID = 0;
	}
}

SceneManager::~SceneManager()
{
	DestroyGLTextures();

	if (m_basicMeshes)
	{
		delete m_basicMeshes;
		m_basicMeshes = nullptr;
	}
}

/***********************************************************/
bool SceneManager::CreateGLTexture(const char* filename, std::string tag)
{
	if (m_loadedTextures >= 16)
		return false;

	int width, height, channels;
	stbi_set_flip_vertically_on_load(true);
	unsigned char* image = stbi_load(filename, &width, &height, &channels, 0);

	if (!image)
	{
		std::cout << "Failed to load texture: " << filename << std::endl;
		return false;
	}

	GLenum format = (channels == 4) ? GL_RGBA : GL_RGB;

	GLuint textureID = 0;
	glGenTextures(1, &textureID);
	glBindTexture(GL_TEXTURE_2D, textureID);

	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

	glTexImage2D(GL_TEXTURE_2D, 0, format, width, height, 0,
		format, GL_UNSIGNED_BYTE, image);

	glBindTexture(GL_TEXTURE_2D, 0);
	stbi_image_free(image);

	m_textureIDs[m_loadedTextures].tag = tag;
	m_textureIDs[m_loadedTextures].ID = textureID;
	m_loadedTextures++;

	return true;
}

void SceneManager::BindGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		glActiveTexture(GL_TEXTURE0 + i);
		glBindTexture(GL_TEXTURE_2D, m_textureIDs[i].ID);
	}
}

void SceneManager::DestroyGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		glDeleteTextures(1, &m_textureIDs[i].ID);
	}
	m_loadedTextures = 0;
}

int SceneManager::FindTextureSlot(std::string tag)
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		if (m_textureIDs[i].tag == tag)
			return i;
	}
	return -1;
}

bool SceneManager::FindMaterial(std::string tag, OBJECT_MATERIAL& material)
{
	for (size_t i = 0; i < m_objectMaterials.size(); i++)
	{
		if (m_objectMaterials[i].tag == tag)
		{
			material = m_objectMaterials[i];
			return true;
		}
	}
	return false;
}

/***********************************************************/
void SceneManager::SetTransformations(glm::vec3 scaleXYZ, float Xrot, float Yrot, float Zrot, glm::vec3 position)
{
	glm::mat4 model =
		glm::translate(position) *
		glm::rotate(glm::radians(Zrot), glm::vec3(0, 0, 1)) *
		glm::rotate(glm::radians(Yrot), glm::vec3(0, 1, 0)) *
		glm::rotate(glm::radians(Xrot), glm::vec3(1, 0, 0)) *
		glm::scale(scaleXYZ);

	m_pShaderManager->setMat4Value(g_ModelName, model);
}

void SceneManager::SetShaderColor(float r, float g, float b, float a)
{
	m_pShaderManager->setVec4Value(g_ObjectColorName, glm::vec4(r, g, b, a));
}

void SceneManager::SetShaderTexture(std::string tag)
{
	int slot = FindTextureSlot(tag);

	if (slot < 0)
	{
		m_pShaderManager->setBoolValue(g_UseTextureName, false);
		return;
	}

	m_pShaderManager->setIntValue(g_ObjectTextureName, slot);
	m_pShaderManager->setBoolValue(g_UseTextureName, true);
}

void SceneManager::SetTextureUVScale(float u, float v)
{
	GLint loc = m_pShaderManager->getUniformLocation("UVscale");
	if (loc >= 0)
	{
		glUniform2f(loc, u, v);
	}
}

void SceneManager::SetShaderMaterial(std::string materialTag)
{
	OBJECT_MATERIAL mat;
	FindMaterial(materialTag, mat);

	m_pShaderManager->setVec3Value("material.diffuseColor", mat.diffuseColor);
	m_pShaderManager->setVec3Value("material.specularColor", mat.specularColor);
	m_pShaderManager->setFloatValue("material.shininess", mat.shininess);
}

/***********************************************************
* Materials used for Phong lighting
***********************************************************/
void SceneManager::DefineObjectMaterials()
{
	m_objectMaterials.clear();

	OBJECT_MATERIAL wood;
	wood.diffuseColor = glm::vec3(0.55f, 0.40f, 0.22f);
	wood.specularColor = glm::vec3(0.08f, 0.08f, 0.08f);
	wood.shininess = 8.0f;
	wood.tag = "wood";
	m_objectMaterials.push_back(wood);

	OBJECT_MATERIAL stone;
	stone.diffuseColor = glm::vec3(0.80f, 0.80f, 0.80f);
	stone.specularColor = glm::vec3(0.22f, 0.22f, 0.22f);
	stone.shininess = 18.0f;
	stone.tag = "stone";
	m_objectMaterials.push_back(stone);

	OBJECT_MATERIAL cap;
	cap.diffuseColor = glm::vec3(0.15f, 0.15f, 0.15f);
	cap.specularColor = glm::vec3(0.05f, 0.05f, 0.05f);
	cap.shininess = 6.0f;
	cap.tag = "cap";
	m_objectMaterials.push_back(cap);

	OBJECT_MATERIAL blackShade;
	blackShade.diffuseColor = glm::vec3(0.07f, 0.07f, 0.07f);
	blackShade.specularColor = glm::vec3(0.12f, 0.12f, 0.12f);
	blackShade.shininess = 10.0f;
	blackShade.tag = "blackShade";
	m_objectMaterials.push_back(blackShade);

	OBJECT_MATERIAL bottlePlastic;
	bottlePlastic.diffuseColor = glm::vec3(0.55f, 0.80f, 1.00f);
	bottlePlastic.specularColor = glm::vec3(0.90f, 0.90f, 0.95f);
	bottlePlastic.shininess = 80.0f;
	bottlePlastic.tag = "bottlePlastic";
	m_objectMaterials.push_back(bottlePlastic);

	OBJECT_MATERIAL candleJar;
	candleJar.diffuseColor = glm::vec3(0.80f, 0.10f, 0.12f);
	candleJar.specularColor = glm::vec3(0.55f, 0.20f, 0.20f);
	candleJar.shininess = 60.0f;
	candleJar.tag = "candleJar";
	m_objectMaterials.push_back(candleJar);

	OBJECT_MATERIAL candleWax;
	candleWax.diffuseColor = glm::vec3(0.92f, 0.90f, 0.84f);
	candleWax.specularColor = glm::vec3(0.18f, 0.16f, 0.14f);
	candleWax.shininess = 22.0f;
	candleWax.tag = "candleWax";
	m_objectMaterials.push_back(candleWax);

	OBJECT_MATERIAL lighterPlastic;
	lighterPlastic.diffuseColor = glm::vec3(1.00f, 0.70f, 0.35f);
	lighterPlastic.specularColor = glm::vec3(0.20f, 0.20f, 0.20f);
	lighterPlastic.shininess = 18.0f;
	lighterPlastic.tag = "lighterPlastic";
	m_objectMaterials.push_back(lighterPlastic);

	OBJECT_MATERIAL darkMetal;
	darkMetal.diffuseColor = glm::vec3(0.18f, 0.18f, 0.18f);
	darkMetal.specularColor = glm::vec3(0.35f, 0.35f, 0.35f);
	darkMetal.shininess = 45.0f;
	darkMetal.tag = "darkMetal";
	m_objectMaterials.push_back(darkMetal);
}

/***********************************************************
* Lighting setup (Phong): Ambient + Diffuse + Specular
***********************************************************/
void SceneManager::SetupSceneLights()
{
	if (!m_pShaderManager) return;

	m_pShaderManager->use();
	m_pShaderManager->setBoolValue(g_UseLightingName, true);

	m_pShaderManager->setBoolValue("directionalLight.bActive", false);
	m_pShaderManager->setBoolValue("spotLight.bActive", false);

	for (int i = 0; i < 5; i++)
	{
		std::ostringstream ss;
		ss << "pointLights[" << i << "].bActive";
		m_pShaderManager->setBoolValue(ss.str().c_str(), false);
	}

	// Light 0: White key
	m_pShaderManager->setBoolValue("pointLights[0].bActive", true);
	m_pShaderManager->setVec3Value("pointLights[0].position", glm::vec3(5.5f, 9.0f, 7.0f));
	m_pShaderManager->setVec3Value("pointLights[0].ambient", glm::vec3(0.16f, 0.16f, 0.16f));
	m_pShaderManager->setVec3Value("pointLights[0].diffuse", glm::vec3(0.90f, 0.90f, 0.90f));
	m_pShaderManager->setVec3Value("pointLights[0].specular", glm::vec3(1.00f, 1.00f, 1.00f));

	// Light 1: Blue fill (colored)
	m_pShaderManager->setBoolValue("pointLights[1].bActive", true);
	m_pShaderManager->setVec3Value("pointLights[1].position", glm::vec3(-7.0f, 7.0f, 3.5f));
	m_pShaderManager->setVec3Value("pointLights[1].ambient", glm::vec3(0.03f, 0.05f, 0.12f));
	m_pShaderManager->setVec3Value("pointLights[1].diffuse", glm::vec3(0.12f, 0.28f, 0.60f));
	m_pShaderManager->setVec3Value("pointLights[1].specular", glm::vec3(0.20f, 0.40f, 0.85f));

	// Light 2: Rim/back light
	m_pShaderManager->setBoolValue("pointLights[2].bActive", true);
	m_pShaderManager->setVec3Value("pointLights[2].position", glm::vec3(0.0f, 6.0f, -10.0f));
	m_pShaderManager->setVec3Value("pointLights[2].ambient", glm::vec3(0.05f, 0.05f, 0.05f));
	m_pShaderManager->setVec3Value("pointLights[2].diffuse", glm::vec3(0.40f, 0.40f, 0.40f));
	m_pShaderManager->setVec3Value("pointLights[2].specular", glm::vec3(0.60f, 0.60f, 0.60f));
}

/***********************************************************/
void SceneManager::PrepareScene()
{
	m_basicMeshes->LoadPlaneMesh();
	m_basicMeshes->LoadBoxMesh();
	m_basicMeshes->LoadCylinderMesh();

	CreateGLTexture("textures/textures_wood.png", "woodTex");
	CreateGLTexture("textures/textures_granite.png", "graniteTex");
	BindGLTextures();

	DefineObjectMaterials();
	SetupSceneLights();
}

/***********************************************************/
void SceneManager::RenderScene()
{
	m_pShaderManager->use();
	m_pShaderManager->setBoolValue(g_UseLightingName, true);
	SetupSceneLights();

	// ============================================================
	// Desk surface rule:
	// - deskTopY is the top of the tabletop slab
	// - Boxes: centerY = deskTopY + (height / 2)
	// - Cylinders (this template): centerY = deskTopY + scaleY
	// ============================================================
	const float deskTopY = 0.0f;

	// ============================================================
	// Photo-based object layout (matches reference image)
	// Back of table is toward the wall (more negative Z).
	// Front of table is closer to camera (less negative Z).
	// ============================================================
	const glm::vec3 phoneXZ = glm::vec3(-5.8f, 0.0f, -3.2f);  // front-left
	const glm::vec3 candleXZ = glm::vec3(-6.6f, 0.0f, -6.4f);  // back-left near wall
	const glm::vec3 lighterXZ = glm::vec3(-4.3f, 0.0f, -5.4f);  // behind phone, closer to candle

	const glm::vec3 laptopXZ = glm::vec3(0.6f, 0.0f, -6.2f);  // back-center
	const glm::vec3 bibleXZ = glm::vec3(1.0f, 0.0f, -6.0f);  // on top of laptop, slightly right

	const glm::vec3 waterXZ = glm::vec3(5.8f, 0.0f, -4.0f);  // right-front
	const glm::vec3 suppXZ = glm::vec3(7.4f, 0.0f, -4.2f);  // far-right

	// =========================
	// FLOOR (BLACK SHADED)
	// =========================
	m_pShaderManager->setBoolValue(g_UseTextureName, false);
	SetShaderMaterial("blackShade");
	SetShaderColor(1, 1, 1, 1);
	SetTransformations(glm::vec3(20.0f, 1.0f, 12.0f), 0, 0, 0, glm::vec3(0, 0, 0));
	m_basicMeshes->DrawPlaneMesh();

	// =========================
	// BACK WALL (BLACK SHADED)
	// =========================
	m_pShaderManager->setBoolValue(g_UseTextureName, false);
	SetShaderMaterial("blackShade");
	SetShaderColor(1, 1, 1, 1);
	SetTransformations(glm::vec3(20.0f, 10.0f, 0.5f), 0, 0, 0, glm::vec3(0, 5, -8.5f));
	m_basicMeshes->DrawBoxMesh();

	// =========================
	// TABLETOP SLAB (WOOD TEX)
	// top surface at deskTopY = 0.0
	// =========================
	SetShaderTexture("woodTex");
	SetTextureUVScale(2.0f, 2.0f);
	SetShaderColor(1, 1, 1, 1);
	SetShaderMaterial("wood");

	// thickness = 0.10 -> center at -0.05 so top is exactly 0.0
	SetTransformations(glm::vec3(16.0f, 0.10f, 10.0f), 0, 0, 0, glm::vec3(0.0f, -0.05f, -3.5f));
	m_basicMeshes->DrawBoxMesh();

	// =========================
	// PHONE (granite texture) — front-left
	// =========================
	const float phoneH = 0.20f;
	const float phoneY = deskTopY + (phoneH * 0.5f);

	SetShaderTexture("graniteTex");
	SetTextureUVScale(1.5f, 1.5f);
	SetShaderColor(1, 1, 1, 1);
	SetShaderMaterial("stone");

	SetTransformations(glm::vec3(3.5f, phoneH, 2.0f), 0, -18.0f, 0,
		glm::vec3(phoneXZ.x, phoneY, phoneXZ.z));
	m_basicMeshes->DrawBoxMesh();

	// =========================
	// LAPTOP (closed) — back-center
	// =========================
	m_pShaderManager->setBoolValue(g_UseTextureName, false);
	SetShaderMaterial("stone");
	SetShaderColor(0.55f, 0.55f, 0.58f, 1.0f);

	const float laptopH = 0.10f;
	const float laptopY = deskTopY + (laptopH * 0.5f);
	SetTransformations(glm::vec3(3.6f, laptopH, 2.3f), 0.0f, 8.0f, 0.0f,
		glm::vec3(laptopXZ.x, laptopY, laptopXZ.z));
	m_basicMeshes->DrawBoxMesh();

	// =========================
	// BIBLE (light green) — on top of laptop
	// =========================
	SetShaderMaterial("wood");
	SetShaderColor(0.70f, 0.90f, 0.70f, 1.0f);

	const float bibleH = 0.30f;
	const float bibleY = deskTopY + laptopH + (bibleH * 0.5f);
	SetTransformations(glm::vec3(3.2f, bibleH, 2.0f), 0.0f, 10.0f, 0.0f,
		glm::vec3(bibleXZ.x, bibleY, bibleXZ.z));
	m_basicMeshes->DrawBoxMesh();

	// =========================
	// CANDLE — back-left near wall
	// =========================
	m_pShaderManager->setBoolValue(g_UseTextureName, false);
	SetShaderColor(1, 1, 1, 1);
	SetShaderMaterial("candleJar");

	SetTransformations(glm::vec3(0.70f, 0.30f, 0.70f), 0, 0, 0,
		glm::vec3(candleXZ.x, deskTopY + 0.30f, candleXZ.z));
	m_basicMeshes->DrawCylinderMesh(true, true, true);

	// Wax
	SetShaderMaterial("candleWax");
	SetShaderColor(0.95f, 0.92f, 0.86f, 1.0f);
	SetTransformations(glm::vec3(0.62f, 0.10f, 0.62f), 0, 0, 0,
		glm::vec3(candleXZ.x, deskTopY + 0.52f, candleXZ.z));
	m_basicMeshes->DrawCylinderMesh(true, true, true);

	// =========================
	// “LITER” prop (thin box) — near lighter area
	// =========================
	SetShaderMaterial("stone");
	SetShaderColor(0.80f, 0.80f, 0.82f, 1.0f);

	const float literH = 0.06f;
	const float literY = deskTopY + (literH * 0.5f);
	const glm::vec3 literPos = glm::vec3(lighterXZ.x - 0.6f, literY, lighterXZ.z + 0.2f);

	SetTransformations(glm::vec3(0.90f, literH, 0.18f), 0.0f, -10.0f, 8.0f, literPos);
	m_basicMeshes->DrawBoxMesh();

	// =========================
	// LIGHTER (light orange) — behind phone, closer to candle
	// =========================
	SetShaderMaterial("lighterPlastic");
	SetShaderColor(1.00f, 0.78f, 0.45f, 1.0f);

	const float lighterH = 0.07f;
	const float lighterY = deskTopY + (lighterH * 0.5f);
	const glm::vec3 lighterPos = glm::vec3(lighterXZ.x, lighterY, lighterXZ.z);

	SetTransformations(glm::vec3(0.55f, lighterH, 0.18f), 0.0f, 20.0f, 0.0f, lighterPos);
	m_basicMeshes->DrawBoxMesh();

	// Lighter metal top
	SetShaderMaterial("darkMetal");
	SetShaderColor(0.25f, 0.25f, 0.25f, 1.0f);

	const glm::vec3 lighterTopPos =
		glm::vec3(lighterPos.x + 0.18f, deskTopY + (0.03f * 0.5f) + 0.07f, lighterPos.z);

	SetTransformations(glm::vec3(0.18f, 0.03f, 0.18f), 0.0f, 20.0f, 0.0f, lighterTopPos);
	m_basicMeshes->DrawBoxMesh();

	// =========================
	// WATER BOTTLE — right-front
	// =========================
	m_pShaderManager->setBoolValue(g_UseTextureName, false);
	SetShaderMaterial("bottlePlastic");
	SetShaderColor(0.55f, 0.80f, 1.00f, 1.0f);

	const float bottleYaw = 15.0f;

	SetTransformations(glm::vec3(0.60f, 1.65f, 0.60f), 0, bottleYaw, 0,
		glm::vec3(waterXZ.x, deskTopY + 1.65f, waterXZ.z));
	m_basicMeshes->DrawCylinderMesh(true, true, true);

	SetTransformations(glm::vec3(0.28f, 0.60f, 0.28f), 0, bottleYaw, 0,
		glm::vec3(waterXZ.x, deskTopY + 3.95f, waterXZ.z));
	m_basicMeshes->DrawCylinderMesh(true, true, true);

	// Cap
	SetShaderMaterial("cap");
	SetShaderColor(0.10f, 0.10f, 0.10f, 1.0f);
	SetTransformations(glm::vec3(0.32f, 0.25f, 0.32f), 0, bottleYaw, 0,
		glm::vec3(waterXZ.x, deskTopY + 4.35f, waterXZ.z));
	m_basicMeshes->DrawCylinderMesh(true, true, true);

	// Black band
	SetShaderColor(0.02f, 0.02f, 0.02f, 1.0f);
	SetTransformations(glm::vec3(0.63f, 0.08f, 0.63f), 0, bottleYaw, 0,
		glm::vec3(waterXZ.x, deskTopY + 2.10f, waterXZ.z));
	m_basicMeshes->DrawCylinderMesh(true, true, true);

	// =========================
	// SUPPLEMENT BOTTLE — far-right
	// =========================
	m_pShaderManager->setBoolValue(g_UseTextureName, false);
	SetShaderMaterial("stone");
	SetShaderColor(0.92f, 0.92f, 0.92f, 1.0f);

	const float suppYaw = 12.0f;

	SetTransformations(glm::vec3(0.55f, 1.20f, 0.55f), 0, suppYaw, 0,
		glm::vec3(suppXZ.x, deskTopY + 1.20f, suppXZ.z));
	m_basicMeshes->DrawCylinderMesh(true, true, true);

	// Cap
	SetShaderMaterial("cap");
	SetShaderColor(0.95f, 0.95f, 0.95f, 1.0f);
	SetTransformations(glm::vec3(0.60f, 0.25f, 0.60f), 0, suppYaw, 0,
		glm::vec3(suppXZ.x, deskTopY + 2.65f, suppXZ.z));
	m_basicMeshes->DrawCylinderMesh(true, true, true);

	// Black band
	SetShaderColor(0.02f, 0.02f, 0.02f, 1.0f);
	SetTransformations(glm::vec3(0.58f, 0.08f, 0.58f), 0, suppYaw, 0,
		glm::vec3(suppXZ.x, deskTopY + 1.55f, suppXZ.z));
	m_basicMeshes->DrawCylinderMesh(true, true, true);
}