#include "ViewManager.h"

#include <iostream>

// GLM
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>

namespace
{
    const char* g_ViewName = "view";
    const char* g_ProjectionName = "projection";
    const char* g_ViewPosName = "viewPosition";
}

ViewManager* ViewManager::s_instance = nullptr;

ViewManager::ViewManager(ShaderManager* pShaderManager)
{
    m_pShaderManager = pShaderManager;

    // ? START CAMERA BACK + UP so the scene is visible immediately
    // Default camera looks down -Z, so this aims toward your wall/objects nicely.
    m_pCamera = new Camera(glm::vec3(0.0f, 6.0f, 18.0f));
}

ViewManager::~ViewManager()
{
    if (m_pCamera)
    {
        delete m_pCamera;
        m_pCamera = nullptr;
    }
}

GLFWwindow* ViewManager::CreateDisplayWindow(const char* windowTitle)
{
    // Create window
    m_windowWidth = 1000;
    m_windowHeight = 800;

    m_window = glfwCreateWindow(m_windowWidth, m_windowHeight, windowTitle, nullptr, nullptr);
    if (!m_window)
    {
        glfwTerminate();
        return nullptr;
    }

    glfwMakeContextCurrent(m_window);

    // register callbacks
    s_instance = this;
    glfwSetFramebufferSizeCallback(m_window, FramebufferSizeCallback);
    glfwSetCursorPosCallback(m_window, MouseCallback);
    glfwSetScrollCallback(m_window, ScrollCallback);
    glfwSetKeyCallback(m_window, KeyCallback);

    // capture mouse for FPS-style look
    glfwSetInputMode(m_window, GLFW_CURSOR, GLFW_CURSOR_DISABLED);

    // ensure viewport matches initial size
    glViewport(0, 0, m_windowWidth, m_windowHeight);

    return m_window;
}

void ViewManager::PrepareSceneView()
{
    if (!m_pShaderManager || !m_pCamera || !m_window) return;

    // timing
    float currentFrame = (float)glfwGetTime();
    m_deltaTime = currentFrame - m_lastFrame;
    m_lastFrame = currentFrame;

    // continuous movement keys
    ProcessContinuousInput(m_deltaTime);

    // shader active
    m_pShaderManager->use();

    // view matrix
    glm::mat4 view = m_pCamera->GetViewMatrix();
    m_pShaderManager->setMat4Value(g_ViewName, view);

    // view position uniform (your fragment shader uses this)
    m_pShaderManager->setVec3Value(g_ViewPosName, m_pCamera->Position);

    // projection matrix
    ApplyProjection();
}

void ViewManager::ProcessContinuousInput(float deltaTime)
{
    // scale movement speed with scroll
    float originalSpeed = m_pCamera->MovementSpeed;
    m_pCamera->MovementSpeed = originalSpeed * m_speedScale;

    // WASD
    if (glfwGetKey(m_window, GLFW_KEY_W) == GLFW_PRESS)
        m_pCamera->ProcessKeyboard(FORWARD, deltaTime);
    if (glfwGetKey(m_window, GLFW_KEY_S) == GLFW_PRESS)
        m_pCamera->ProcessKeyboard(BACKWARD, deltaTime);
    if (glfwGetKey(m_window, GLFW_KEY_A) == GLFW_PRESS)
        m_pCamera->ProcessKeyboard(LEFT, deltaTime);
    if (glfwGetKey(m_window, GLFW_KEY_D) == GLFW_PRESS)
        m_pCamera->ProcessKeyboard(RIGHT, deltaTime);

    // QE (vertical)
    if (glfwGetKey(m_window, GLFW_KEY_Q) == GLFW_PRESS)
        m_pCamera->ProcessKeyboard(DOWN, deltaTime);
    if (glfwGetKey(m_window, GLFW_KEY_E) == GLFW_PRESS)
        m_pCamera->ProcessKeyboard(UP, deltaTime);

    // restore base
    m_pCamera->MovementSpeed = originalSpeed;
}

void ViewManager::ApplyProjection()
{
    glViewport(0, 0, m_windowWidth, m_windowHeight);

    glm::mat4 projection(1.0f);

    if (m_usePerspective)
    {
        projection = glm::perspective(
            glm::radians(m_pCamera->Zoom),
            (float)m_windowWidth / (float)m_windowHeight,
            0.1f,
            100.0f
        );
    }
    else
    {
        float orthoScale = 6.0f;
        float aspect = (float)m_windowWidth / (float)m_windowHeight;

        float left = -orthoScale * aspect;
        float right = orthoScale * aspect;
        float bottom = -orthoScale;
        float top = orthoScale;

        projection = glm::ortho(left, right, bottom, top, 0.1f, 100.0f);
    }

    m_pShaderManager->setMat4Value(g_ProjectionName, projection);
}

/* -------------------- CALLBACKS -------------------- */

void ViewManager::FramebufferSizeCallback(GLFWwindow* window, int width, int height)
{
    if (!s_instance) return;

    s_instance->m_windowWidth = (width > 0) ? width : 1;
    s_instance->m_windowHeight = (height > 0) ? height : 1;

    glViewport(0, 0, s_instance->m_windowWidth, s_instance->m_windowHeight);
}

void ViewManager::MouseCallback(GLFWwindow* window, double xpos, double ypos)
{
    if (!s_instance || !s_instance->m_pCamera) return;

    float x = (float)xpos;
    float y = (float)ypos;

    if (s_instance->m_firstMouse)
    {
        s_instance->m_lastX = x;
        s_instance->m_lastY = y;
        s_instance->m_firstMouse = false;
    }

    float xoffset = x - s_instance->m_lastX;
    float yoffset = s_instance->m_lastY - y;

    s_instance->m_lastX = x;
    s_instance->m_lastY = y;

    s_instance->m_pCamera->ProcessMouseMovement(xoffset, yoffset);
}

void ViewManager::ScrollCallback(GLFWwindow* window, double xoffset, double yoffset)
{
    if (!s_instance) return;

    // rubric: scroll adjusts movement speed
    s_instance->m_speedScale += (float)yoffset * 0.10f;

    if (s_instance->m_speedScale < 0.20f) s_instance->m_speedScale = 0.20f;
    if (s_instance->m_speedScale > 5.00f) s_instance->m_speedScale = 5.00f;
}

void ViewManager::KeyCallback(GLFWwindow* window, int key, int scancode, int action, int mods)
{
    if (!s_instance) return;

    if (action == GLFW_PRESS)
    {
        if (key == GLFW_KEY_P) s_instance->m_usePerspective = true;
        if (key == GLFW_KEY_O) s_instance->m_usePerspective = false;

        if (key == GLFW_KEY_ESCAPE)
            glfwSetWindowShouldClose(window, true);
    }
}