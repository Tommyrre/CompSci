"""Application configuration loaded from environment variables."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import os

from dotenv import load_dotenv

BASE_DIR = Path(__file__).resolve().parent.parent
load_dotenv(BASE_DIR / ".env")


def _to_bool(value: str | None, default: bool = False) -> bool:
    if value is None:
        return default
    return value.strip().lower() in {"1", "true", "yes", "on"}


@dataclass(frozen=True)
class Settings:
    """Strongly typed settings used throughout the application."""

    app_title: str = os.getenv("APP_TITLE", "Grazioso Salvare Dashboard")
    data_source: str = os.getenv("DATA_SOURCE", "csv").strip().lower()
    csv_path: Path = BASE_DIR / os.getenv("CSV_PATH", "data/aac_shelter_outcomes.csv")
    mongo_uri: str = os.getenv("MONGO_URI", "mongodb://localhost:27017")
    mongo_database: str = os.getenv("MONGO_DATABASE", "AAC")
    mongo_collection: str = os.getenv("MONGO_COLLECTION", "animals")
    mongo_apply_schema: bool = _to_bool(os.getenv("MONGO_APPLY_SCHEMA"), True)
    debug: bool = _to_bool(os.getenv("DEBUG"), False)
    page_size: int = int(os.getenv("PAGE_SIZE", "10"))


settings = Settings()
