"""Dash layout components kept separate from callback logic."""

from __future__ import annotations

from dash import Dash, dash_table, dcc, html
import pandas as pd

from .config import settings


def create_layout(app: Dash, initial_data: pd.DataFrame, source_name: str) -> html.Div:
    """Build and return the application layout."""
    columns = [
        {"name": column.replace("_", " ").title(), "id": column, "selectable": True}
        for column in initial_data.columns
    ]

    return html.Div(
        className="page-shell",
        children=[
            dcc.Store(id="animal-store", data=initial_data.to_dict("records")),
            html.Header(
                className="app-header",
                children=[
                    html.Img(
                        src=app.get_asset_url("Grazioso_Salvare_Logo.png"),
                        className="app-logo",
                        alt="Grazioso Salvare logo",
                    ),
                    html.Div(
                        [
                            html.H1(settings.app_title),
                            html.P("Rescue animal selection and location dashboard"),
                            html.Small(f"Current data source: {source_name}"),
                        ]
                    ),
                ],
            ),
            html.Section(
                className="panel",
                children=[
                    html.Label("Choose a rescue profile", htmlFor="filter-type"),
                    dcc.RadioItems(
                        id="filter-type",
                        value="reset",
                        inline=True,
                        options=[
                            {"label": "Reset", "value": "reset"},
                            {"label": "Water Rescue", "value": "water"},
                            {"label": "Mountain/Wilderness", "value": "mountain"},
                            {"label": "Disaster/Tracking", "value": "disaster"},
                        ],
                    ),
                    html.Div(
                        style={"display": "grid", "gridTemplateColumns": "2fr 1fr 1fr", "gap": "12px", "marginTop": "14px"},
                        children=[
                            dcc.Input(
                                id="search-term",
                                type="search",
                                debounce=True,
                                placeholder="Search ID, name, breed, color, or outcome...",
                                style={"width": "100%"},
                            ),
                            dcc.Dropdown(
                                id="sort-by",
                                value="animal_id",
                                clearable=False,
                                options=[
                                    {"label": "Animal ID", "value": "animal_id"},
                                    {"label": "Name", "value": "name"},
                                    {"label": "Animal Type", "value": "animal_type"},
                                    {"label": "Breed", "value": "breed"},
                                    {"label": "Age", "value": "age_upon_outcome_in_weeks"},
                                    {"label": "Outcome", "value": "outcome_type"},
                                ],
                            ),
                            dcc.RadioItems(
                                id="sort-order",
                                value="asc",
                                inline=True,
                                options=[
                                    {"label": "Ascending", "value": "asc"},
                                    {"label": "Descending", "value": "desc"},
                                ],
                            ),
                        ],
                    ),
                    html.Div(id="status-message", className="status-message"),
                    html.Div(id="summary-cards", style={"marginTop": "10px"}),
                ],
            ),
            html.Section(
                className="panel",
                children=[
                    dash_table.DataTable(
                        id="datatable-id",
                        columns=columns,
                        data=initial_data.to_dict("records"),
                        page_size=settings.page_size,
                        page_action="native",
                        sort_action="native",
                        filter_action="native",
                        row_selectable="single",
                        selected_rows=[0] if not initial_data.empty else [],
                        style_table={"overflowX": "auto"},
                        style_header={"fontWeight": "bold"},
                        style_cell={
                            "padding": "8px",
                            "textAlign": "left",
                            "minWidth": "110px",
                            "maxWidth": "230px",
                            "overflow": "hidden",
                            "textOverflow": "ellipsis",
                        },
                    )
                ],
            ),
            html.Section(
                className="visual-grid",
                children=[
                    html.Div(id="graph-id", className="panel"),
                    html.Div(id="map-id", className="panel"),
                ],
            ),
        ],
    )
