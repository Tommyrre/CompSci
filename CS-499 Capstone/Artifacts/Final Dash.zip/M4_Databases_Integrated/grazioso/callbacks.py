"""Interactive dashboard callbacks."""

from __future__ import annotations

import logging

import dash_leaflet as dl
import pandas as pd
import plotly.express as px
from dash import Dash, Input, Output, dcc, html

from .service import AnimalService

logger = logging.getLogger(__name__)


def register_callbacks(app: Dash, service: AnimalService) -> None:
    """Register all callbacks with the supplied Dash application."""

    @app.callback(
        Output("animal-store", "data"),
        Output("status-message", "children"),
        Output("summary-cards", "children"),
        Input("filter-type", "value"),
        Input("search-term", "value"),
        Input("sort-by", "value"),
        Input("sort-order", "value"),
    )
    def load_animals(
        rescue_type: str,
        search_term: str | None,
        sort_by: str,
        sort_order: str,
    ):
        try:
            frame = service.get_animals(rescue_type, search_term, sort_by, sort_order)
            summary = service.summarize(frame)
            cards = html.Div(
                style={"display": "flex", "gap": "18px", "flexWrap": "wrap"},
                children=[
                    html.Strong(f"Total: {summary.total_records:,}"),
                    html.Span(f"Dogs: {summary.dog_records:,}"),
                    html.Span(f"Cats: {summary.cat_records:,}"),
                    html.Span(f"Unique breeds: {summary.unique_breeds:,}"),
                ],
            )
            return frame.to_dict("records"), f"Showing {len(frame):,} animal record(s).", cards
        except RuntimeError as exc:
            logger.exception("Unable to update the rescue-animal selection")
            message = html.Span(str(exc), className="error-message")
            return [], message, ""

    @app.callback(
        Output("datatable-id", "data"),
        Output("datatable-id", "columns"),
        Output("datatable-id", "selected_rows"),
        Output("datatable-id", "page_current"),
        Input("animal-store", "data"),
    )
    def update_table(records: list[dict] | None):
        safe_records = records or []
        columns = []
        if safe_records:
            columns = [
                {"name": key.replace("_", " ").title(), "id": key, "selectable": True}
                for key in safe_records[0]
            ]
        return safe_records, columns, [0] if safe_records else [], 0

    @app.callback(
        Output("graph-id", "children"),
        Input("datatable-id", "derived_virtual_data"),
    )
    def update_graph(view_data: list[dict] | None):
        frame = pd.DataFrame(view_data or [])
        if frame.empty or "breed" not in frame.columns:
            return html.P("No breed data is available for this selection.")

        # Count once, show the ten most common breeds, and combine the remainder.
        counts = frame["breed"].fillna("Unknown").value_counts()
        top = counts.head(10)
        remainder = int(counts.iloc[10:].sum())
        if remainder:
            top.loc["Other"] = remainder
        chart_data = top.rename_axis("breed").reset_index(name="count")

        figure = px.pie(chart_data, names="breed", values="count", title="Top Breed Distribution")
        return dcc.Graph(figure=figure, config={"displayModeBar": False})

    @app.callback(
        Output("map-id", "children"),
        Input("datatable-id", "derived_virtual_data"),
        Input("datatable-id", "derived_virtual_selected_rows"),
    )
    def update_map(view_data: list[dict] | None, selected_rows: list[int] | None):
        frame = pd.DataFrame(view_data or [])
        required = {"location_lat", "location_long"}
        if frame.empty or not required.issubset(frame.columns):
            return html.P("No location data is available for this selection.")

        row_index = selected_rows[0] if selected_rows else 0
        if row_index >= len(frame):
            row_index = 0

        record = frame.iloc[row_index]
        try:
            position = [float(record["location_lat"]), float(record["location_long"])]
        except (TypeError, ValueError):
            return html.P("The selected record does not contain a valid location.")

        return html.Div(
            [
                html.H3("Selected Animal Location"),
                dl.Map(
                    center=position,
                    zoom=10,
                    style={"height": "450px", "width": "100%"},
                    children=[
                        dl.TileLayer(),
                        dl.Marker(
                            position=position,
                            children=[
                                dl.Tooltip(str(record.get("breed", "Unknown breed"))),
                                dl.Popup(
                                    [
                                        html.Strong(str(record.get("name") or "Unnamed animal")),
                                        html.Br(),
                                        str(record.get("animal_id", "")),
                                    ]
                                ),
                            ],
                        ),
                    ],
                ),
            ]
        )
