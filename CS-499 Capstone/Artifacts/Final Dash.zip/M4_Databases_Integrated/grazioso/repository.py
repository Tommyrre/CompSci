"""Database access layer for animal records.

Milestone Four strengthens the original CRUD implementation with schema
validation, indexes, sanitized queries, aggregation, and consistent error
handling. CSV support remains available so the dashboard can be demonstrated
without exposing credentials or requiring a live MongoDB instance.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from pathlib import Path
from typing import Any, Mapping
import logging

import pandas as pd
from pymongo import ASCENDING, MongoClient
from pymongo.collection import Collection
from pymongo.errors import DuplicateKeyError, PyMongoError

logger = logging.getLogger(__name__)

ALLOWED_QUERY_FIELDS = frozenset(
    {
        "animal_id",
        "name",
        "animal_type",
        "breed",
        "color",
        "date_of_birth",
        "datetime",
        "monthyear",
        "outcome_subtype",
        "outcome_type",
        "sex_upon_outcome",
        "age_upon_outcome",
        "age_upon_outcome_in_weeks",
        "location_lat",
        "location_long",
    }
)
ALLOWED_QUERY_OPERATORS = frozenset({"$in", "$gte", "$lte", "$eq"})

ANIMAL_VALIDATOR: dict[str, Any] = {
    "$jsonSchema": {
        "bsonType": "object",
        "required": ["animal_id", "animal_type", "breed"],
        "properties": {
            "animal_id": {
                "bsonType": "string",
                "minLength": 1,
                "description": "Unique animal identifier is required.",
            },
            "animal_type": {
                "bsonType": "string",
                "enum": ["Dog", "Cat", "Bird", "Livestock", "Other"],
            },
            "breed": {"bsonType": "string", "minLength": 1},
            "name": {"bsonType": ["string", "null"]},
            "age_upon_outcome_in_weeks": {
                "bsonType": ["int", "long", "double", "decimal", "null"],
                "minimum": 0,
            },
            "location_lat": {
                "bsonType": ["int", "long", "double", "decimal", "null"],
                "minimum": -90,
                "maximum": 90,
            },
            "location_long": {
                "bsonType": ["int", "long", "double", "decimal", "null"],
                "minimum": -180,
                "maximum": 180,
            },
        },
    }
}


class AnimalRepository(ABC):
    """Common interface for animal record storage."""

    @abstractmethod
    def read(self, query: dict[str, Any] | None = None) -> list[dict[str, Any]]:
        """Return animal records matching the supplied query."""

    @abstractmethod
    def create(self, document: Mapping[str, Any]) -> str:
        """Create an animal record and return its identifier."""

    @abstractmethod
    def update(self, animal_id: str, changes: Mapping[str, Any]) -> bool:
        """Update one animal record and report whether it changed."""

    @abstractmethod
    def delete(self, animal_id: str) -> bool:
        """Delete one animal record and report whether it existed."""

    def aggregate_by_breed(self, query: dict[str, Any] | None = None) -> list[dict[str, Any]]:
        """Return breed counts. Repositories may override for server-side work."""
        records = self.read(query)
        frame = pd.DataFrame.from_records(records)
        if frame.empty or "breed" not in frame.columns:
            return []
        counts = frame["breed"].fillna("Unknown").value_counts()
        return [{"breed": str(breed), "count": int(count)} for breed, count in counts.items()]


class CsvAnimalRepository(AnimalRepository):
    """Read animal records from CSV while caching parsed data in memory."""

    def __init__(self, csv_path: Path) -> None:
        if not csv_path.exists():
            raise FileNotFoundError(f"Animal data file was not found: {csv_path}")
        self.csv_path = csv_path
        self._frame_cache: pd.DataFrame | None = None

    def _load_frame(self) -> pd.DataFrame:
        if self._frame_cache is None:
            try:
                frame = pd.read_csv(self.csv_path)
                self._frame_cache = frame.drop(columns=["Unnamed: 0"], errors="ignore")
                logger.info("Cached %,d animal records from CSV", len(self._frame_cache))
            except (OSError, pd.errors.ParserError) as exc:
                logger.exception("Unable to read the animal CSV file")
                raise RuntimeError("The animal data file could not be loaded.") from exc
        return self._frame_cache

    def read(self, query: dict[str, Any] | None = None) -> list[dict[str, Any]]:
        safe_query = sanitize_query(query)
        frame = self._load_frame()
        result = _apply_query(frame, safe_query) if safe_query else frame
        return result.where(pd.notna(result), None).to_dict("records")

    def create(self, document: Mapping[str, Any]) -> str:
        raise RuntimeError("CSV demonstration mode is read-only. Use MongoDB for CRUD operations.")

    def update(self, animal_id: str, changes: Mapping[str, Any]) -> bool:
        raise RuntimeError("CSV demonstration mode is read-only. Use MongoDB for CRUD operations.")

    def delete(self, animal_id: str) -> bool:
        raise RuntimeError("CSV demonstration mode is read-only. Use MongoDB for CRUD operations.")


class MongoAnimalRepository(AnimalRepository):
    """MongoDB repository with validation, indexes, CRUD, and aggregation."""

    def __init__(
        self,
        uri: str,
        database: str,
        collection: str,
        *,
        apply_schema: bool = True,
    ) -> None:
        if not uri.strip():
            raise ValueError("A MongoDB connection string is required.")
        self.client = MongoClient(
            uri,
            serverSelectionTimeoutMS=5000,
            connectTimeoutMS=5000,
            retryWrites=True,
        )
        self.database = self.client[database]
        self.collection_name = collection
        self.collection: Collection = self.database[collection]
        self.apply_schema = apply_schema

    def initialize(self) -> None:
        """Verify connectivity, apply validation, and create useful indexes."""
        try:
            self.client.admin.command("ping")
            if self.apply_schema:
                self._ensure_schema_validation()
            self._ensure_indexes()
            logger.info("MongoDB repository initialized successfully")
        except PyMongoError as exc:
            logger.exception("MongoDB initialization failed")
            raise RuntimeError("The MongoDB database could not be initialized.") from exc

    def ping(self) -> None:
        try:
            self.client.admin.command("ping")
        except PyMongoError as exc:
            logger.exception("MongoDB connection validation failed")
            raise RuntimeError("The MongoDB database is unavailable.") from exc

    def _ensure_schema_validation(self) -> None:
        existing = self.database.list_collection_names()
        if self.collection_name not in existing:
            self.database.create_collection(
                self.collection_name,
                validator=ANIMAL_VALIDATOR,
                validationLevel="moderate",
                validationAction="error",
            )
            self.collection = self.database[self.collection_name]
            return

        self.database.command(
            "collMod",
            self.collection_name,
            validator=ANIMAL_VALIDATOR,
            validationLevel="moderate",
            validationAction="error",
        )

    def _ensure_indexes(self) -> None:
        """Create indexes that support common filters and prevent duplicates."""
        self.collection.create_index(
            [("animal_id", ASCENDING)], unique=True, name="ux_animal_id"
        )
        self.collection.create_index(
            [
                ("animal_type", ASCENDING),
                ("breed", ASCENDING),
                ("age_upon_outcome_in_weeks", ASCENDING),
            ],
            name="ix_rescue_profile",
        )
        self.collection.create_index([("outcome_type", ASCENDING)], name="ix_outcome_type")

    def read(self, query: dict[str, Any] | None = None) -> list[dict[str, Any]]:
        safe_query = sanitize_query(query)
        try:
            cursor = self.collection.find(safe_query, {"_id": 0})
            return list(cursor)
        except PyMongoError as exc:
            logger.exception("MongoDB read operation failed")
            raise RuntimeError("Animal records could not be loaded from MongoDB.") from exc

    def create(self, document: Mapping[str, Any]) -> str:
        clean_document = validate_document(document, require_core_fields=True)
        try:
            result = self.collection.insert_one(clean_document)
            return str(result.inserted_id)
        except DuplicateKeyError as exc:
            raise ValueError("An animal with that animal_id already exists.") from exc
        except PyMongoError as exc:
            logger.exception("MongoDB create operation failed")
            raise RuntimeError("The animal record could not be created.") from exc

    def update(self, animal_id: str, changes: Mapping[str, Any]) -> bool:
        if not animal_id.strip():
            raise ValueError("animal_id is required for updates.")
        clean_changes = validate_document(changes, require_core_fields=False)
        clean_changes.pop("animal_id", None)  # immutable business identifier
        if not clean_changes:
            raise ValueError("At least one valid field must be supplied for an update.")
        try:
            result = self.collection.update_one(
                {"animal_id": animal_id.strip()}, {"$set": clean_changes}
            )
            return result.modified_count == 1
        except PyMongoError as exc:
            logger.exception("MongoDB update operation failed")
            raise RuntimeError("The animal record could not be updated.") from exc

    def delete(self, animal_id: str) -> bool:
        if not animal_id.strip():
            raise ValueError("animal_id is required for deletion.")
        try:
            result = self.collection.delete_one({"animal_id": animal_id.strip()})
            return result.deleted_count == 1
        except PyMongoError as exc:
            logger.exception("MongoDB delete operation failed")
            raise RuntimeError("The animal record could not be deleted.") from exc

    def aggregate_by_breed(self, query: dict[str, Any] | None = None) -> list[dict[str, Any]]:
        """Count breeds inside MongoDB to avoid transferring unnecessary rows."""
        safe_query = sanitize_query(query)
        pipeline: list[dict[str, Any]] = []
        if safe_query:
            pipeline.append({"$match": safe_query})
        pipeline.extend(
            [
                {"$group": {"_id": {"$ifNull": ["$breed", "Unknown"]}, "count": {"$sum": 1}}},
                {"$sort": {"count": -1, "_id": 1}},
                {"$project": {"_id": 0, "breed": "$_id", "count": 1}},
            ]
        )
        try:
            return list(self.collection.aggregate(pipeline, allowDiskUse=False))
        except PyMongoError as exc:
            logger.exception("MongoDB aggregation failed")
            raise RuntimeError("Breed totals could not be calculated.") from exc


def sanitize_query(query: Mapping[str, Any] | None) -> dict[str, Any]:
    """Allow only expected fields/operators to reduce query-injection risk."""
    if not query:
        return {}
    safe: dict[str, Any] = {}
    for field, condition in query.items():
        if field not in ALLOWED_QUERY_FIELDS:
            raise ValueError(f"Unsupported query field: {field}")
        if not isinstance(condition, Mapping):
            safe[field] = condition
            continue
        safe_condition: dict[str, Any] = {}
        for operator, value in condition.items():
            if operator not in ALLOWED_QUERY_OPERATORS:
                raise ValueError(f"Unsupported query operator: {operator}")
            safe_condition[operator] = value
        safe[field] = safe_condition
    return safe


def validate_document(
    document: Mapping[str, Any], *, require_core_fields: bool
) -> dict[str, Any]:
    """Validate application-level fields before sending data to MongoDB."""
    clean = {key: value for key, value in document.items() if key in ALLOWED_QUERY_FIELDS}
    if require_core_fields:
        missing = [field for field in ("animal_id", "animal_type", "breed") if not clean.get(field)]
        if missing:
            raise ValueError(f"Missing required field(s): {', '.join(missing)}")
    if "animal_id" in clean and not str(clean["animal_id"]).strip():
        raise ValueError("animal_id cannot be blank.")
    if "age_upon_outcome_in_weeks" in clean and clean["age_upon_outcome_in_weeks"] is not None:
        if float(clean["age_upon_outcome_in_weeks"]) < 0:
            raise ValueError("Age cannot be negative.")
    return clean


def _apply_query(frame: pd.DataFrame, query: dict[str, Any]) -> pd.DataFrame:
    """Apply validated Mongo-style filters with vectorized Boolean indexing."""
    mask = pd.Series(True, index=frame.index)
    for field, condition in query.items():
        if field not in frame.columns:
            return frame.iloc[0:0]
        if not isinstance(condition, dict):
            mask &= frame[field].eq(condition)
            continue
        if "$eq" in condition:
            mask &= frame[field].eq(condition["$eq"])
        if "$in" in condition:
            mask &= frame[field].isin(set(condition["$in"]))
        if "$gte" in condition:
            mask &= frame[field].ge(condition["$gte"])
        if "$lte" in condition:
            mask &= frame[field].le(condition["$lte"])
    return frame.loc[mask]
