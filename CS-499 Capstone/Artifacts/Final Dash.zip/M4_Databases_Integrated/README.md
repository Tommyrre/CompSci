# CS 499 Milestone Four: Databases Enhancement

This project enhances the original CS 340 Animal Shelter Dashboard for the CS 499 database category. It retains the modular software engineering and algorithm improvements from earlier milestones while adding professional MongoDB design, validation, performance, security, and reliability features.

## Database Enhancements

- Added complete MongoDB CRUD methods: create, read, update, and delete.
- Added application-level document validation before database writes.
- Added MongoDB JSON Schema validation for required fields, numeric ranges, and accepted animal types.
- Added a unique index on `animal_id` to prevent duplicate records.
- Added a compound rescue-profile index on animal type, breed, and age.
- Added an outcome-type index for common reporting and filtering.
- Added query-field and operator allowlists to reduce NoSQL query-injection risk.
- Added a server-side MongoDB aggregation pipeline for breed counts.
- Added connection validation, timeouts, retryable writes, centralized logging, and consistent exception handling.
- Kept credentials outside source code through `.env` configuration.
- Preserved read-only CSV fallback mode so the artifact can be reviewed without a database server.

## Project Structure

- `app.py` – application factory and repository selection
- `grazioso/repository.py` – enhanced database layer, validation, indexes, CRUD, and aggregation
- `grazioso/service.py` – business rules, searching, filtering, sorting, and summaries
- `grazioso/callbacks.py` – dashboard interaction logic
- `grazioso/layout.py` – presentation layer
- `grazioso/config.py` – environment-based settings

## Run in CSV Demonstration Mode

```powershell
py -m venv .venv
.\.venv\Scripts\Activate.ps1
py -m pip install -r requirements.txt
Copy-Item .env.example .env
py app.py
```

Open `http://127.0.0.1:8050`.

## Run with MongoDB

Update `.env`:

```text
DATA_SOURCE=mongo
MONGO_URI=mongodb://localhost:27017
MONGO_DATABASE=AAC
MONGO_COLLECTION=animals
MONGO_APPLY_SCHEMA=true
```

Use a least-privilege MongoDB account in a real environment. The account needs collection read/write access and, when `MONGO_APPLY_SCHEMA=true`, permission to create indexes and modify collection validation rules. Set `MONGO_APPLY_SCHEMA=false` when those administrative actions are managed separately.

## Suggested Screenshots for the Narrative

1. `grazioso/repository.py`: `ANIMAL_VALIDATOR` and the allowed query fields/operators.
2. `grazioso/repository.py`: `initialize()`, `_ensure_schema_validation()`, and `_ensure_indexes()`.
3. `grazioso/repository.py`: `create()`, `update()`, and `delete()`.
4. `grazioso/repository.py`: `aggregate_by_breed()`.
5. `app.py`: `build_service()` showing secure environment configuration and repository initialization.
6. Running dashboard in CSV or MongoDB mode.

## Integrated Milestone Coverage

This is one cumulative project. The files are not separated into milestone folders:

- Milestone Two improvements remain integrated in `app.py`, `grazioso/config.py`, `grazioso/layout.py`, `grazioso/callbacks.py`, `grazioso/service.py`, and `grazioso/repository.py` through the modular application structure, environment configuration, logging, exception handling, and repository/service separation.
- Milestone Three improvements remain integrated in `grazioso/service.py`, `grazioso/callbacks.py`, and `grazioso/repository.py` through multi-field searching, validated stable sorting, rescue filters, pagination support, cached CSV access, summaries, and vectorized filtering.
- Milestone Four enhancements are integrated into `grazioso/repository.py`, `grazioso/config.py`, and `app.py` through MongoDB schema validation, indexes, full CRUD operations, aggregation, safer queries, connection initialization, and protected configuration.
