"""Application entry point for the enhanced Grazioso Salvare dashboard."""

from __future__ import annotations

import logging

from dash import Dash, html

from grazioso.callbacks import register_callbacks
from grazioso.config import settings
from grazioso.layout import create_layout
from grazioso.repository import CsvAnimalRepository, MongoAnimalRepository
from grazioso.service import AnimalService

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
)
logger = logging.getLogger(__name__)


def build_service() -> tuple[AnimalService, str]:
    """Create the selected data repository and its service layer."""
    if settings.data_source == "mongo":
        repository = MongoAnimalRepository(
            settings.mongo_uri,
            settings.mongo_database,
            settings.mongo_collection,
            apply_schema=settings.mongo_apply_schema,
        )
        repository.initialize()
        return AnimalService(repository), "MongoDB"

    repository = CsvAnimalRepository(settings.csv_path)
    return AnimalService(repository), "Recovered AAC CSV"


def create_app() -> Dash:
    """Application factory that supports testing and future maintenance."""
    app = Dash(__name__, title=settings.app_title)

    try:
        service, source_name = build_service()
        initial_data = service.get_animals()
        app.layout = create_layout(app, initial_data, source_name)
        register_callbacks(app, service)
    except (FileNotFoundError, RuntimeError) as exc:
        logger.exception("Application startup failed")
        app.layout = html.Div(
            className="startup-error",
            children=[
                html.H1("Grazioso Salvare Dashboard"),
                html.P("The application could not start."),
                html.Code(str(exc)),
            ],
        )

    return app


app = create_app()
server = app.server

if __name__ == "__main__":
    app.run(debug=settings.debug)
