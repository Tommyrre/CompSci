from pymongo import MongoClient


class AnimalShelter(object):
    """CRUD operations for the Animal collection in MongoDB."""

    def __init__(self, username, password):
        # Connection variables
        HOST = "localhost"
        PORT = 27017
        DB = "aac"
        COL = "animals"

        # Initialize connection
        self.client = MongoClient(
            f"mongodb://{username}:{password}@{HOST}:{PORT}/?authSource=admin"
        )
        self.database = self.client[DB]
        self.collection = self.database[COL]

    # Create
    def create(self, data):
        try:
            if data is not None:
                self.collection.insert_one(data)
                return True
            raise Exception("Nothing to save, because data parameter is empty")
        except Exception as e:
            print("Create failed:", e)
            return False

    # Read
    def read(self, query):
        try:
            if query is not None:
                data = self.collection.find(query)
                return list(data)
            return []
        except Exception as e:
            print("Read failed:", e)
            return []

    # Update
    def update(self, query, new_values):
        try:
            if query is not None and new_values is not None:
                result = self.collection.update_many(query, {"$set": new_values})
                return result.modified_count
            raise Exception("Query or update values are missing")
        except Exception as e:
            print("Update failed:", e)
            return 0

    # Delete
    def delete(self, query):
        try:
            if query is not None:
                result = self.collection.delete_many(query)
                return result.deleted_count
            raise Exception("Query parameter is missing")
        except Exception as e:
            print("Delete failed:", e)
            return 0