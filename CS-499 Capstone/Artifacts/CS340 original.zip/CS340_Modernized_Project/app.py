from __future__ import annotations

import logging
from pathlib import Path

import dash_leaflet as dl
import pandas as pd
import plotly.express as px
from dash import Dash, Input, Output, State, callback_context, dash_table, dcc, html

from grazioso.config import settings
from grazioso.repository import CsvAnimalRepository, MongoAnimalRepository
from grazioso.service import AnimalService

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
logger = logging.getLogger(__name__)
ROOT = Path(__file__).resolve().parent


def build_service() -> tuple[AnimalService, str]:
    if settings.data_source == "mongo":
        repository = MongoAnimalRepository(settings.mongo_uri, settings.mongo_database, settings.mongo_collection)
        repository.ping()
        repository.ensure_indexes()
        return AnimalService(repository), "MongoDB"
    return AnimalService(CsvAnimalRepository(ROOT / "data" / "aac_shelter_outcomes.csv")), "AAC CSV (10,000 records)"


try:
    service, source_label = build_service()
    startup_error = ""
except Exception as exc:
    logger.exception("Configured data source failed; falling back to sample data")
    service = AnimalService(CsvAnimalRepository(ROOT / "data" / "aac_shelter_outcomes.csv"))
    source_label = "AAC CSV fallback"
    startup_error = str(exc)

initial_frame = service.get_animals()
app = Dash(__name__, title=settings.app_title, suppress_callback_exceptions=True)
server = app.server

CARD_STYLE = {"padding": "16px", "borderRadius": "12px", "background": "white", "boxShadow": "0 2px 10px rgba(0,0,0,.08)"}

app.layout = html.Div(
    style={"fontFamily": "Arial, sans-serif", "background": "#f4f6f8", "minHeight": "100vh", "padding": "24px"},
    children=[
        dcc.Store(id="animal-store", data=initial_frame.to_dict("records")),
        html.Div(style={"display": "flex", "alignItems": "center", "gap": "20px", **CARD_STYLE}, children=[
            html.Img(src=app.get_asset_url("Grazioso Salvare Logo.png"), style={"height": "90px"}),
            html.Div([
                html.H1(settings.app_title, style={"margin": 0}),
                html.P("Rescue-animal analysis and placement dashboard", style={"marginBottom": "4px"}),
                html.Small(f"Data source: {source_label}"),
            ]),
        ]),
        html.Div(id="startup-alert", children=(html.Div(f"MongoDB connection issue: {startup_error}. The included AAC CSV is displayed.", style={"marginTop": "16px", "padding": "12px", "background": "#fff3cd", "borderRadius": "8px"}) if startup_error else None)),
        html.Div(style={"marginTop": "18px", **CARD_STYLE}, children=[
            html.Label("Rescue profile", style={"fontWeight": "bold"}),
            dcc.Dropdown(id="filter-type", clearable=False, value="reset", options=[
                {"label": "All animals", "value": "reset"},
                {"label": "Water rescue", "value": "water"},
                {"label": "Mountain / wilderness rescue", "value": "mountain"},
                {"label": "Disaster / tracking rescue", "value": "disaster"},
            ]),
            html.Div(id="status-message", style={"marginTop": "10px"}),
        ]),
        html.Div(id="summary-cards", style={"display": "grid", "gridTemplateColumns": "repeat(3, minmax(0,1fr))", "gap": "16px", "marginTop": "18px"}),
        html.Div(style={"marginTop": "18px", **CARD_STYLE}, children=[
            dash_table.DataTable(
                id="datatable-id",
                columns=[{"name": c.replace("_", " ").title(), "id": c, "selectable": True} for c in initial_frame.columns],
                data=initial_frame.to_dict("records"), page_size=settings.page_size,
                sort_action="native", filter_action="native", page_action="native",
                row_selectable="single", selected_rows=[0] if not initial_frame.empty else [],
                style_table={"overflowX": "auto"},
                style_header={"fontWeight": "bold", "background": "#e9ecef"},
                style_cell={"padding": "9px", "textAlign": "left", "minWidth": "110px", "maxWidth": "240px", "overflow": "hidden", "textOverflow": "ellipsis"},
                style_data_conditional=[{"if": {"row_index": "odd"}, "backgroundColor": "#fafafa"}],
            )
        ]),
        html.Div(style={"display": "grid", "gridTemplateColumns": "1fr 1fr", "gap": "18px", "marginTop": "18px"}, children=[
            html.Div(id="graph-id", style=CARD_STYLE),
            html.Div(id="map-id", style=CARD_STYLE),
        ]),
    ],
)


@app.callback(
    Output("animal-store", "data"), Output("status-message", "children"),
    Input("filter-type", "value"), prevent_initial_call=False,
)
def load_animals(filter_type: str):
    try:
        frame = service.get_animals(filter_type)
        return frame.to_dict("records"), f"Showing {len(frame):,} matching record(s)."
    except Exception as exc:
        logger.exception("Dashboard query failed")
        return [], html.Span(f"Unable to load records: {exc}", style={"color": "#b00020"})


@app.callback(
    Output("datatable-id", "data"), Output("datatable-id", "columns"), Output("datatable-id", "selected_rows"),
    Input("animal-store", "data"),
)
def update_table(records):
    records = records or []
    columns = [{"name": c.replace("_", " ").title(), "id": c, "selectable": True} for c in (records[0].keys() if records else initial_frame.columns)]
    return records, columns, [0] if records else []


@app.callback(Output("summary-cards", "children"), Input("datatable-id", "derived_virtual_data"))
def update_summary(view_data):
    frame = pd.DataFrame(view_data or [])
    total = len(frame)
    breeds = frame["breed"].nunique() if "breed" in frame else 0
    avg_age = frame["age_upon_outcome_in_weeks"].mean() if "age_upon_outcome_in_weeks" in frame and not frame.empty else 0
    values = [("Animals", f"{total:,}"), ("Unique breeds", f"{breeds:,}"), ("Average age", f"{avg_age:.1f} weeks")]
    return [html.Div([html.Small(label), html.H2(value, style={"margin": "6px 0 0"})], style=CARD_STYLE) for label, value in values]


@app.callback(Output("graph-id", "children"), Input("datatable-id", "derived_virtual_data"))
def update_graph(view_data):
    frame = pd.DataFrame(view_data or [])
    if frame.empty or "breed" not in frame:
        return html.P("No breed data is available for this selection.")
    counts = frame["breed"].value_counts().head(10).reset_index()
    counts.columns = ["breed", "count"]
    figure = px.bar(counts, x="count", y="breed", orientation="h", title="Top breeds in current view")
    figure.update_layout(yaxis={"categoryorder": "total ascending"}, margin={"l": 10, "r": 10, "t": 50, "b": 10})
    return dcc.Graph(figure=figure, config={"displayModeBar": False})


@app.callback(
    Output("map-id", "children"),
    Input("datatable-id", "derived_virtual_data"), Input("datatable-id", "derived_virtual_selected_rows"),
)
def update_map(view_data, selected_rows):
    frame = pd.DataFrame(view_data or [])
    if frame.empty or not {"location_lat", "location_long"}.issubset(frame.columns):
        return html.P("No location data is available for this selection.")
    row_index = selected_rows[0] if selected_rows and selected_rows[0] < len(frame) else 0
    record = frame.iloc[row_index]
    try:
        position = [float(record["location_lat"]), float(record["location_long"])]
    except (TypeError, ValueError):
        return html.P("The selected animal does not have a valid location.")
    return html.Div([
        html.H3("Selected animal location"),
        dl.Map(center=position, zoom=11, style={"height": "420px", "width": "100%"}, children=[
            dl.TileLayer(),
            dl.Marker(position=position, children=[
                dl.Tooltip(str(record.get("breed", "Unknown breed"))),
                dl.Popup([html.Strong(str(record.get("name", "Unnamed animal"))), html.Br(), str(record.get("animal_id", ""))]),
            ]),
        ]),
    ])


if __name__ == "__main__":
    app.run(debug=settings.debug)
