from pathlib import Path
import pandas as pd
from grazioso.repository import apply_dataframe_query, CsvAnimalRepository
from grazioso.service import AnimalService


def test_dataframe_query_supports_in_and_range():
    frame = pd.DataFrame({"breed": ["A", "B", "C"], "age": [10, 20, 30]})
    result = apply_dataframe_query(frame, {"breed": {"$in": ["B", "C"]}, "age": {"$gte": 20, "$lte": 25}})
    assert result["breed"].tolist() == ["B"]


def test_sample_repository_returns_records():
    path = Path(__file__).parents[1] / "data" / "sample_animals.csv"
    service = AnimalService(CsvAnimalRepository(path))
    assert not service.get_animals("water").empty
