# Grazioso Salvare Dashboard — Modernized CS 499 Version

This project modernizes the original CS 340 rescue-animal dashboard while preserving its purpose and core filters. It is ready for Visual Studio 2022 or Visual Studio Code and includes the full AAC dataset with **10,000 animal records**.

## What is included

- Full `data/aac_shelter_outcomes.csv` dataset with 10,000 records
- Original Water Rescue, Mountain/Wilderness, and Disaster/Tracking filters
- Sortable and searchable data table with pagination
- Summary cards, breed chart, and selected-animal map
- Secure environment configuration with no passwords stored in source code
- Optional MongoDB support with indexes and error handling
- Local CSV mode that runs immediately without MongoDB
- Automated tests and the recovered original project files

## Run in Visual Studio 2022

1. Extract the ZIP file.
2. Open **Visual Studio Installer** and confirm that the **Python development** workload is installed.
3. Open Visual Studio 2022.
4. Select **Open a local folder**.
5. Choose the extracted `CS340_Modernized_Project` folder.
6. Open **View > Other Windows > Python Environments**.
7. Create or select a Python 3 environment.
8. Open a terminal in the project folder and run:

```powershell
py -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
```

9. Copy `.env.example` and rename the copy to `.env`.
10. Leave `DATA_SOURCE=csv` to use the included 10,000-record file.
11. Right-click `app.py` and choose **Set as Startup File**.
12. Run the project. Open the address shown in the terminal, usually:

```text
http://127.0.0.1:8050
```

## CSV mode

The project uses this file by default:

```text
data/aac_shelter_outcomes.csv
```

No MongoDB installation is required for CSV mode. The application reads the complete local dataset and applies all rescue filters directly to the records.

## Optional MongoDB mode

After installing MongoDB, import the included CSV into database `aac` and collection `animals`:

```powershell
mongoimport --db aac --collection animals --type csv --headerline --drop --file "data/aac_shelter_outcomes.csv"
```

Then update `.env`:

```env
DATA_SOURCE=mongo
MONGO_URI=mongodb://localhost:27017
MONGO_DATABASE=aac
MONGO_COLLECTION=animals
```

The application creates indexes for `animal_type`, `breed`, and `age_upon_outcome_in_weeks`. If MongoDB cannot connect, it safely falls back to the included AAC CSV.

## Tests

```powershell
pytest
```

## Project structure

- `app.py`: Dash interface and callbacks
- `grazioso/config.py`: environment configuration
- `grazioso/repository.py`: MongoDB and CSV data access
- `grazioso/service.py`: rescue filters and business logic
- `data/aac_shelter_outcomes.csv`: full 10,000-record AAC dataset
- `data/sample_animals.csv`: small backup demonstration dataset
- `assets/`: logo and visual assets
- `tests/`: automated tests
- `original_project_files/`: recovered CS 340 files for comparison
