from dataclasses import dataclass
import os
from dotenv import load_dotenv

load_dotenv()


def _as_bool(value: str | None, default: bool = False) -> bool:
    if value is None:
        return default
    return value.strip().lower() in {"1", "true", "yes", "on"}


@dataclass(frozen=True)
class Settings:
    app_title: str = os.getenv("APP_TITLE", "Grazioso Salvare Dashboard")
    data_source: str = os.getenv("DATA_SOURCE", "sample").lower()
    mongo_uri: str = os.getenv("MONGO_URI", "mongodb://localhost:27017")
    mongo_database: str = os.getenv("MONGO_DATABASE", "aac")
    mongo_collection: str = os.getenv("MONGO_COLLECTION", "animals")
    debug: bool = _as_bool(os.getenv("DEBUG"), False)
    page_size: int = int(os.getenv("PAGE_SIZE", "12"))


settings = Settings()
