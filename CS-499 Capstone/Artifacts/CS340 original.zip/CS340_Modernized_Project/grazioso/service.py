from __future__ import annotations
from typing import Any
import pandas as pd
from .repository import AnimalRepository

RESCUE_FILTERS: dict[str, dict[str, Any]] = {
    "water": {
        "animal_type": "Dog",
        "breed": {"$in": ["Labrador Retriever Mix", "Chesapeake Bay Retriever"]},
        "age_upon_outcome_in_weeks": {"$gte": 26, "$lte": 156},
    },
    "mountain": {
        "animal_type": "Dog",
        "breed": {"$in": ["German Shepherd", "Alaskan Malamute", "Old English Sheepdog", "Siberian Husky", "Rottweiler"]},
        "age_upon_outcome_in_weeks": {"$gte": 26, "$lte": 156},
    },
    "disaster": {
        "animal_type": "Dog",
        "breed": {"$in": ["Doberman Pinscher", "German Shepherd", "Golden Retriever", "Bloodhound", "Rottweiler"]},
        "age_upon_outcome_in_weeks": {"$gte": 20, "$lte": 300},
    },
}

DISPLAY_COLUMNS = [
    "animal_id", "name", "animal_type", "breed", "sex_upon_outcome",
    "age_upon_outcome_in_weeks", "outcome_type", "location_lat", "location_long"
]


class AnimalService:
    def __init__(self, repository: AnimalRepository) -> None:
        self.repository = repository

    def get_animals(self, filter_name: str = "reset") -> pd.DataFrame:
        query = RESCUE_FILTERS.get(filter_name, {})
        frame = pd.DataFrame.from_records(self.repository.read(query))
        if frame.empty:
            return pd.DataFrame(columns=DISPLAY_COLUMNS)
        if "_id" in frame.columns:
            frame = frame.drop(columns=["_id"])
        ordered = [column for column in DISPLAY_COLUMNS if column in frame.columns]
        extras = [column for column in frame.columns if column not in ordered]
        return frame[ordered + extras]
