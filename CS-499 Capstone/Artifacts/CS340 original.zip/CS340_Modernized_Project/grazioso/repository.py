from __future__ import annotations

from abc import ABC, abstractmethod
from pathlib import Path
from typing import Any
import logging

import pandas as pd
try:
    from pymongo import ASCENDING, MongoClient
    from pymongo.errors import PyMongoError
except ImportError:  # Allows sample-data mode before optional packages are installed.
    ASCENDING = 1
    MongoClient = None
    PyMongoError = Exception

logger = logging.getLogger(__name__)


class AnimalRepository(ABC):
    @abstractmethod
    def read(self, query: dict[str, Any] | None = None) -> list[dict[str, Any]]:
        raise NotImplementedError

    @abstractmethod
    def create(self, data: dict[str, Any]) -> str:
        raise NotImplementedError

    @abstractmethod
    def update(self, query: dict[str, Any], values: dict[str, Any]) -> int:
        raise NotImplementedError

    @abstractmethod
    def delete(self, query: dict[str, Any]) -> int:
        raise NotImplementedError


class MongoAnimalRepository(AnimalRepository):
    def __init__(self, uri: str, database: str, collection: str) -> None:
        if MongoClient is None:
            raise RuntimeError("pymongo is required for MongoDB mode. Install requirements.txt first.")
        self.client = MongoClient(uri, serverSelectionTimeoutMS=5000)
        self.collection = self.client[database][collection]

    def ping(self) -> None:
        self.client.admin.command("ping")

    def ensure_indexes(self) -> None:
        self.collection.create_index([("animal_type", ASCENDING)])
        self.collection.create_index([("breed", ASCENDING)])
        self.collection.create_index([("age_upon_outcome_in_weeks", ASCENDING)])

    def read(self, query: dict[str, Any] | None = None) -> list[dict[str, Any]]:
        try:
            return list(self.collection.find(query or {}, {"_id": 0}))
        except PyMongoError as exc:
            logger.exception("MongoDB read failed")
            raise RuntimeError("Unable to read animal records from MongoDB.") from exc

    def create(self, data: dict[str, Any]) -> str:
        _validate_document(data)
        try:
            return str(self.collection.insert_one(data).inserted_id)
        except PyMongoError as exc:
            logger.exception("MongoDB create failed")
            raise RuntimeError("Unable to create the animal record.") from exc

    def update(self, query: dict[str, Any], values: dict[str, Any]) -> int:
        _validate_document(query, "query")
        _validate_document(values, "values")
        try:
            return self.collection.update_many(query, {"$set": values}).modified_count
        except PyMongoError as exc:
            logger.exception("MongoDB update failed")
            raise RuntimeError("Unable to update animal records.") from exc

    def delete(self, query: dict[str, Any]) -> int:
        _validate_document(query, "query")
        try:
            return self.collection.delete_many(query).deleted_count
        except PyMongoError as exc:
            logger.exception("MongoDB delete failed")
            raise RuntimeError("Unable to delete animal records.") from exc


class CsvAnimalRepository(AnimalRepository):
    """Read-only local repository used when the original MongoDB data is unavailable."""

    def __init__(self, csv_path: Path) -> None:
        self.csv_path = csv_path

    def read(self, query: dict[str, Any] | None = None) -> list[dict[str, Any]]:
        frame = pd.read_csv(self.csv_path)
        frame = frame.loc[:, ~frame.columns.str.startswith("Unnamed:")]
        if query:
            frame = apply_dataframe_query(frame, query)
        return frame.where(pd.notna(frame), None).to_dict("records")

    def create(self, data: dict[str, Any]) -> str:
        raise RuntimeError("Sample-data mode is read-only. Switch DATA_SOURCE to mongo.")

    def update(self, query: dict[str, Any], values: dict[str, Any]) -> int:
        raise RuntimeError("Sample-data mode is read-only. Switch DATA_SOURCE to mongo.")

    def delete(self, query: dict[str, Any]) -> int:
        raise RuntimeError("Sample-data mode is read-only. Switch DATA_SOURCE to mongo.")


def apply_dataframe_query(frame: pd.DataFrame, query: dict[str, Any]) -> pd.DataFrame:
    result = frame.copy()
    for field, condition in query.items():
        if field not in result.columns:
            return result.iloc[0:0]
        if isinstance(condition, dict):
            if "$in" in condition:
                result = result[result[field].isin(condition["$in"])]
            if "$gte" in condition:
                result = result[result[field] >= condition["$gte"]]
            if "$lte" in condition:
                result = result[result[field] <= condition["$lte"]]
        else:
            result = result[result[field] == condition]
    return result


def _validate_document(value: dict[str, Any], label: str = "data") -> None:
    if not isinstance(value, dict) or not value:
        raise ValueError(f"{label.capitalize()} must be a non-empty dictionary.")
