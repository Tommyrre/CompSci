"""Data access layer for animal records.

Milestone Four adds database validation, indexes, full CRUD operations,
aggregation, and safer query handling while preserving the modular design and
algorithm improvements completed in earlier milestones.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from pathlib import Path
from typing import Any, Mapping
import logging

import pandas as pd
from pymongo import ASCENDING, MongoClient
from pymongo.errors import DuplicateKeyError, PyMongoError

logger = logging.getLogger(__name__)

ALLOWED_QUERY_FIELDS: frozenset[str] = frozenset(
    {
        "animal_id",
        "name",
        "animal_type",
        "breed",
        "color",
        "sex_upon_outcome",
        "outcome_type",
        "age_upon_outcome_in_weeks",
        "location_lat",
        "location_long",
    }
)
ALLOWED_QUERY_OPERATORS: frozenset[str] = frozenset({"$eq", "$in", "$gte", "$lte"})

ANIMAL_VALIDATOR: dict[str, Any] = {
    "$jsonSchema": {
        "bsonType": "object",
        "required": ["animal_id", "animal_type", "breed"],
        "properties": {
            "animal_id": {"bsonType": "string", "minLength": 1},
            "name": {"bsonType": ["string", "null"]},
            "animal_type": {"bsonType": "string", "minLength": 1},
            "breed": {"bsonType": "string", "minLength": 1},
            "age_upon_outcome_in_weeks": {
                "bsonType": ["int", "long", "double", "decimal", "null"],
                "minimum": 0,
            },
            "location_lat": {
                "bsonType": ["int", "long", "double", "decimal", "null"],
                "minimum": -90,
                "maximum": 90,
            },
            "location_long": {
                "bsonType": ["int", "long", "double", "decimal", "null"],
                "minimum": -180,
                "maximum": 180,
            },
        },
    }
}


class AnimalRepository(ABC):
    """Common interface for animal record storage."""

    @abstractmethod
    def read(self, query: dict[str, Any] | None = None) -> list[dict[str, Any]]:
        """Return animal records matching the supplied query."""

    def create(self, document: Mapping[str, Any]) -> str:
        raise NotImplementedError("This repository is read-only.")

    def update(self, animal_id: str, changes: Mapping[str, Any]) -> bool:
        raise NotImplementedError("This repository is read-only.")

    def delete(self, animal_id: str) -> bool:
        raise NotImplementedError("This repository is read-only.")

    def aggregate_by_breed(
        self, query: dict[str, Any] | None = None
    ) -> list[dict[str, Any]]:
        records = self.read(query)
        if not records:
            return []
        frame = pd.DataFrame.from_records(records)
        if "breed" not in frame.columns:
            return []
        counts = (
            frame["breed"]
            .fillna("Unknown")
            .value_counts()
            .rename_axis("breed")
            .reset_index(name="count")
        )
        return counts.to_dict("records")


class CsvAnimalRepository(AnimalRepository):
    """Read animal records from CSV while caching the parsed data in memory."""

    def __init__(self, csv_path: Path) -> None:
        if not csv_path.exists():
            raise FileNotFoundError(f"Animal data file was not found: {csv_path}")
        self.csv_path = csv_path
        self._frame_cache: pd.DataFrame | None = None

    def _load_frame(self) -> pd.DataFrame:
        """Parse the CSV once instead of repeating disk I/O for every filter."""
        if self._frame_cache is None:
            try:
                frame = pd.read_csv(self.csv_path)
                self._frame_cache = frame.drop(columns=["Unnamed: 0"], errors="ignore")
                logger.info("Cached %,d animal records from CSV", len(self._frame_cache))
            except (OSError, pd.errors.ParserError) as exc:
                logger.exception("Unable to read the animal CSV file")
                raise RuntimeError("The animal data file could not be loaded.") from exc
        return self._frame_cache

    def read(self, query: dict[str, Any] | None = None) -> list[dict[str, Any]]:
        frame = self._load_frame()
        result = _apply_query(frame, sanitize_query(query)) if query else frame
        return result.where(pd.notna(result), None).to_dict("records")


class MongoAnimalRepository(AnimalRepository):
    """MongoDB repository with validation, indexes, CRUD, and aggregation."""

    def __init__(
        self,
        uri: str,
        database: str,
        collection: str,
        *,
        apply_schema: bool = True,
    ) -> None:
        self.client = MongoClient(
            uri,
            serverSelectionTimeoutMS=5000,
            connectTimeoutMS=5000,
            retryWrites=True,
        )
        self.database = self.client[database]
        self.collection_name = collection
        self.collection = self.database[collection]
        self.apply_schema = apply_schema

    def initialize(self) -> None:
        """Verify connectivity, apply validation, and create useful indexes."""
        try:
            self.client.admin.command("ping")
            if self.apply_schema:
                self._ensure_schema_validation()
            self._ensure_indexes()
            logger.info("MongoDB repository initialized successfully")
        except PyMongoError as exc:
            logger.exception("MongoDB initialization failed")
            raise RuntimeError("The MongoDB database could not be initialized.") from exc

    def ping(self) -> None:
        """Verify that the configured MongoDB server is available."""
        try:
            self.client.admin.command("ping")
        except PyMongoError as exc:
            logger.exception("MongoDB connection validation failed")
            raise RuntimeError("The MongoDB database is unavailable.") from exc

    def _ensure_schema_validation(self) -> None:
        """Create or update collection-level JSON Schema validation."""
        if self.collection_name not in self.database.list_collection_names():
            self.database.create_collection(
                self.collection_name,
                validator=ANIMAL_VALIDATOR,
                validationLevel="moderate",
                validationAction="error",
            )
            self.collection = self.database[self.collection_name]
            return

        self.database.command(
            "collMod",
            self.collection_name,
            validator=ANIMAL_VALIDATOR,
            validationLevel="moderate",
            validationAction="error",
        )

    def _ensure_indexes(self) -> None:
        """Create indexes for uniqueness and common dashboard filters."""
        self.collection.create_index(
            [("animal_id", ASCENDING)], unique=True, name="ux_animal_id"
        )
        self.collection.create_index(
            [
                ("animal_type", ASCENDING),
                ("breed", ASCENDING),
                ("age_upon_outcome_in_weeks", ASCENDING),
            ],
            name="ix_rescue_profile",
        )
        self.collection.create_index(
            [("outcome_type", ASCENDING)], name="ix_outcome_type"
        )

    def read(self, query: dict[str, Any] | None = None) -> list[dict[str, Any]]:
        safe_query = sanitize_query(query)
        try:
            return list(self.collection.find(safe_query, {"_id": 0}))
        except PyMongoError as exc:
            logger.exception("MongoDB read operation failed")
            raise RuntimeError("Animal records could not be loaded from MongoDB.") from exc

    def create(self, document: Mapping[str, Any]) -> str:
        clean_document = validate_document(document, require_core_fields=True)
        try:
            result = self.collection.insert_one(clean_document)
            logger.info("Created animal record %s", clean_document["animal_id"])
            return str(result.inserted_id)
        except DuplicateKeyError as exc:
            raise ValueError("An animal with that animal_id already exists.") from exc
        except PyMongoError as exc:
            logger.exception("MongoDB create operation failed")
            raise RuntimeError("The animal record could not be created.") from exc

    def update(self, animal_id: str, changes: Mapping[str, Any]) -> bool:
        animal_id = animal_id.strip()
        if not animal_id:
            raise ValueError("animal_id is required for updates.")

        clean_changes = validate_document(changes, require_core_fields=False)
        clean_changes.pop("animal_id", None)
        if not clean_changes:
            raise ValueError("At least one valid field must be supplied for an update.")

        try:
            result = self.collection.update_one(
                {"animal_id": animal_id}, {"$set": clean_changes}
            )
            logger.info("Updated animal record %s", animal_id)
            return result.modified_count == 1
        except PyMongoError as exc:
            logger.exception("MongoDB update operation failed")
            raise RuntimeError("The animal record could not be updated.") from exc

    def delete(self, animal_id: str) -> bool:
        animal_id = animal_id.strip()
        if not animal_id:
            raise ValueError("animal_id is required for deletion.")

        try:
            result = self.collection.delete_one({"animal_id": animal_id})
            logger.info("Deleted animal record %s", animal_id)
            return result.deleted_count == 1
        except PyMongoError as exc:
            logger.exception("MongoDB delete operation failed")
            raise RuntimeError("The animal record could not be deleted.") from exc

    def aggregate_by_breed(
        self, query: dict[str, Any] | None = None
    ) -> list[dict[str, Any]]:
        """Count breeds within MongoDB to reduce transferred data."""
        safe_query = sanitize_query(query)
        pipeline: list[dict[str, Any]] = []
        if safe_query:
            pipeline.append({"$match": safe_query})
        pipeline.extend(
            [
                {"$group": {"_id": {"$ifNull": ["$breed", "Unknown"]}, "count": {"$sum": 1}}},
                {"$sort": {"count": -1, "_id": 1}},
                {"$project": {"_id": 0, "breed": "$_id", "count": 1}},
            ]
        )
        try:
            return list(self.collection.aggregate(pipeline, allowDiskUse=False))
        except PyMongoError as exc:
            logger.exception("MongoDB aggregation failed")
            raise RuntimeError("Breed totals could not be calculated.") from exc


def sanitize_query(query: Mapping[str, Any] | None) -> dict[str, Any]:
    """Allow only expected fields and operators to reduce injection risk."""
    if not query:
        return {}

    safe: dict[str, Any] = {}
    for field, condition in query.items():
        if field not in ALLOWED_QUERY_FIELDS:
            raise ValueError(f"Unsupported query field: {field}")
        if not isinstance(condition, Mapping):
            safe[field] = condition
            continue

        safe_condition: dict[str, Any] = {}
        for operator, value in condition.items():
            if operator not in ALLOWED_QUERY_OPERATORS:
                raise ValueError(f"Unsupported query operator: {operator}")
            safe_condition[operator] = value
        safe[field] = safe_condition
    return safe


def validate_document(
    document: Mapping[str, Any], *, require_core_fields: bool
) -> dict[str, Any]:
    """Validate application-level data before sending it to MongoDB."""
    if not isinstance(document, Mapping):
        raise ValueError("The animal record must be a field-value mapping.")

    clean = {key: value for key, value in document.items() if key in ALLOWED_QUERY_FIELDS}
    if require_core_fields:
        missing = [
            field
            for field in ("animal_id", "animal_type", "breed")
            if not str(clean.get(field, "")).strip()
        ]
        if missing:
            raise ValueError(f"Missing required field(s): {', '.join(missing)}")

    for field in ("animal_id", "animal_type", "breed"):
        if field in clean and isinstance(clean[field], str):
            clean[field] = clean[field].strip()

    age = clean.get("age_upon_outcome_in_weeks")
    if age is not None and float(age) < 0:
        raise ValueError("age_upon_outcome_in_weeks cannot be negative.")

    latitude = clean.get("location_lat")
    if latitude is not None and not -90 <= float(latitude) <= 90:
        raise ValueError("location_lat must be between -90 and 90.")

    longitude = clean.get("location_long")
    if longitude is not None and not -180 <= float(longitude) <= 180:
        raise ValueError("location_long must be between -180 and 180.")

    return clean


def _apply_query(frame: pd.DataFrame, query: dict[str, Any]) -> pd.DataFrame:
    """Apply sanitized Mongo-style filters with vectorized Boolean indexing."""
    mask = pd.Series(True, index=frame.index)

    for field, condition in query.items():
        if field not in frame.columns:
            return frame.iloc[0:0]
        if not isinstance(condition, dict):
            mask &= frame[field].eq(condition)
            continue
        if "$eq" in condition:
            mask &= frame[field].eq(condition["$eq"])
        if "$in" in condition:
            accepted_values = set(condition["$in"])
            mask &= frame[field].isin(accepted_values)
        if "$gte" in condition:
            mask &= frame[field].ge(condition["$gte"])
        if "$lte" in condition:
            mask &= frame[field].le(condition["$lte"])

    return frame.loc[mask]
