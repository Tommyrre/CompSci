"""Algorithms and data-processing logic for rescue-animal selections."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Iterable

import pandas as pd

from .repository import AnimalRepository

RESCUE_FILTERS: dict[str, dict[str, Any]] = {
    "water": {
        "animal_type": "Dog",
        "breed": {"$in": ["Labrador Retriever Mix", "Chesapeake Bay Retriever"]},
        "age_upon_outcome_in_weeks": {"$gte": 26, "$lte": 156},
    },
    "mountain": {
        "animal_type": "Dog",
        "breed": {
            "$in": [
                "German Shepherd",
                "Alaskan Malamute",
                "Old English Sheepdog",
                "Siberian Husky",
                "Rottweiler",
            ]
        },
        "age_upon_outcome_in_weeks": {"$gte": 26, "$lte": 156},
    },
    "disaster": {
        "animal_type": "Dog",
        "breed": {
            "$in": [
                "Doberman Pinscher",
                "German Shepherd",
                "Golden Retriever",
                "Bloodhound",
                "Rottweiler",
            ]
        },
        "age_upon_outcome_in_weeks": {"$gte": 20, "$lte": 300},
    },
}

# A tuple is used because the collection is fixed, ordered, and immutable.
SEARCHABLE_COLUMNS: tuple[str, ...] = (
    "animal_id",
    "name",
    "animal_type",
    "breed",
    "color",
    "sex_upon_outcome",
    "outcome_type",
)

SORTABLE_COLUMNS: frozenset[str] = frozenset(
    {
        "animal_id",
        "name",
        "animal_type",
        "breed",
        "age_upon_outcome_in_weeks",
        "outcome_type",
    }
)


@dataclass(frozen=True)
class AnimalSummary:
    """Small immutable result object used by the dashboard status panel."""

    total_records: int
    dog_records: int
    cat_records: int
    unique_breeds: int


class AnimalService:
    """Coordinate filtering, searching, sorting, and summary calculations."""

    def __init__(self, repository: AnimalRepository) -> None:
        self.repository = repository

    def get_animals(
        self,
        rescue_type: str = "reset",
        search_term: str | None = None,
        sort_by: str = "animal_id",
        sort_order: str = "asc",
    ) -> pd.DataFrame:
        """Return clean, searched, and sorted animal data.

        Filtering is pushed into the repository first to reduce the number of
        records that later algorithms must process. Keyword searching then uses
        a vectorized Boolean mask, and sorting uses pandas' stable mergesort so
        records with equal keys retain their original relative order.
        """
        query = RESCUE_FILTERS.get(rescue_type, {})
        frame = pd.DataFrame.from_records(self.repository.read(query))

        if frame.empty:
            return pd.DataFrame()

        frame = frame.drop(columns=["_id", "Unnamed: 0"], errors="ignore")
        frame = self._search(frame, search_term)
        frame = self._sort(frame, sort_by, sort_order)
        return frame.reset_index(drop=True)


    def create_animal(self, document: dict[str, Any]) -> str:
        """Create a validated animal record through the repository layer."""
        return self.repository.create(document)

    def update_animal(self, animal_id: str, changes: dict[str, Any]) -> bool:
        """Update an existing animal record by its unique identifier."""
        return self.repository.update(animal_id, changes)

    def delete_animal(self, animal_id: str) -> bool:
        """Delete an animal record by its unique identifier."""
        return self.repository.delete(animal_id)

    def breed_totals(self, rescue_type: str = "reset") -> list[dict[str, Any]]:
        """Return repository-level breed counts for the selected rescue filter."""
        query = RESCUE_FILTERS.get(rescue_type, {})
        return self.repository.aggregate_by_breed(query)

    @staticmethod
    def _search(frame: pd.DataFrame, search_term: str | None) -> pd.DataFrame:
        """Search several fields with one vectorized pass per available column."""
        term = (search_term or "").strip()
        if not term:
            return frame

        available = [column for column in SEARCHABLE_COLUMNS if column in frame.columns]
        if not available:
            return frame.iloc[0:0]

        # Build one Boolean Series per column, then combine them with OR.
        masks: Iterable[pd.Series] = (
            frame[column].fillna("").astype(str).str.contains(term, case=False, regex=False)
            for column in available
        )
        combined = pd.concat(masks, axis=1).any(axis=1)
        return frame.loc[combined]

    @staticmethod
    def _sort(frame: pd.DataFrame, sort_by: str, sort_order: str) -> pd.DataFrame:
        """Apply validated stable sorting to the selected field."""
        safe_column = sort_by if sort_by in SORTABLE_COLUMNS else "animal_id"
        if safe_column not in frame.columns:
            return frame

        ascending = sort_order != "desc"
        return frame.sort_values(
            by=safe_column,
            ascending=ascending,
            kind="mergesort",
            na_position="last",
        )

    @staticmethod
    def summarize(frame: pd.DataFrame) -> AnimalSummary:
        """Calculate dashboard summary values in linear time, O(n)."""
        if frame.empty:
            return AnimalSummary(0, 0, 0, 0)

        animal_types = frame.get("animal_type", pd.Series(dtype=str)).fillna("")
        breeds = frame.get("breed", pd.Series(dtype=str)).dropna()
        return AnimalSummary(
            total_records=len(frame),
            dog_records=int(animal_types.eq("Dog").sum()),
            cat_records=int(animal_types.eq("Cat").sum()),
            unique_breeds=int(breeds.nunique()),
        )
