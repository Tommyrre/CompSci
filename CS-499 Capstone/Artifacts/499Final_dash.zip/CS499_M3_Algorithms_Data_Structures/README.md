# CS 499 Milestone Four: Databases

This is one cumulative Visual Studio project containing the improvements from all three enhancement categories:

- **Milestone Two:** modular application architecture, environment configuration, logging, validation, and exception handling.
- **Milestone Three:** multi-field searching, rescue filtering, stable sorting, caching, summaries, and efficient pandas processing.
- **Milestone Four:** MongoDB JSON Schema validation, full CRUD operations, indexes, aggregation, safer query handling, duplicate protection, and database initialization.

## Run the application

1. Create and activate a Python virtual environment.
2. Install dependencies: `pip install -r requirements.txt`
3. Copy `.env.example` to `.env` and update values as needed.
4. Run: `python app.py`

The default `DATA_SOURCE=csv` allows the dashboard to run without MongoDB. Set `DATA_SOURCE=mongo` to use the enhanced MongoDB repository.

## Database enhancement locations

The main Milestone Four code is in `grazioso/repository.py`:

- `ANIMAL_VALIDATOR`: collection-level JSON Schema.
- `MongoAnimalRepository.initialize`: connection, schema, and index setup.
- `_ensure_indexes`: unique and compound indexes.
- `create`, `read`, `update`, `delete`: enhanced CRUD operations.
- `aggregate_by_breed`: server-side aggregation pipeline.
- `sanitize_query`: field/operator allowlists.
- `validate_document`: application-level validation.

`grazioso/service.py` exposes CRUD and aggregation through the service layer, and `app.py` initializes MongoDB securely from environment settings.
